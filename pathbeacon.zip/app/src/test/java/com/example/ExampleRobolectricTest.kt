package com.example

import android.content.Context
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.unit.LayoutDirection
import androidx.test.core.app.ApplicationProvider
import com.example.localization.LocalLocalizedContext
import com.example.localization.createLocalizedContext
import com.example.localization.layoutDirectionForTag
import com.example.model.AdSlotSpec
import com.example.model.AudioCueEntry
import com.example.model.HazardSeverity
import com.example.ui.RadarUiState
import com.example.ui.components.ClarityLanguageDialog
import com.example.ui.screens.CueLogScreen
import com.example.ui.screens.LiveRadarScreen
import com.example.ui.theme.PathBeaconTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun `app_name string matches PathBeacon`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("PathBeacon", appName)
  }

  @Test
  fun `localized contexts resolve voice cue templates across major languages`() {
    val baseContext = ApplicationProvider.getApplicationContext<Context>()
    val tags = listOf("en", "es", "fr", "de", "ja", "hi", "ar", "zh-CN")

    for (tag in tags) {
      val locCtx = baseContext.createLocalizedContext(tag)
      val repeatLabel = locCtx.getString(R.string.repeat_audio_cue)
      val pathClearCue = locCtx.getString(R.string.cue_path_clear)
      assertTrue("Repeat label blank for $tag", repeatLabel.isNotBlank())
      assertTrue("Clear cue blank for $tag", pathClearCue.isNotBlank())
    }

    assertEquals(LayoutDirection.Rtl, layoutDirectionForTag("ar"))
    assertEquals(LayoutDirection.Ltr, layoutDirectionForTag("es"))
  }

  @Test
  fun `live radar screen displays Repeat Audio Cue button and banner ad placeholder`() {
    val baseContext = ApplicationProvider.getApplicationContext<Context>()
    var repeatClicked = false
    var languageClicked = false
    var inspectedAd: AdSlotSpec? = null

    composeTestRule.setContent {
      CompositionLocalProvider(LocalLocalizedContext provides baseContext) {
        PathBeaconTheme {
          LiveRadarScreen(
            uiState =
              RadarUiState(
                hasCameraPermission = false,
                currentCueText = "Caution: Chair at 12 o'clock, nearby.",
                highestSeverity = HazardSeverity.CAUTION,
              ),
            localizedContextProvider = { baseContext },
            onRequestCameraPermission = {},
            onOpenAppSettings = {},
            onFrameAnalyzed = {},
            onToggleScanning = {},
            onToggleTorch = {},
            onToggleAutoSpeak = {},
            onRepeatAudioCue = { repeatClicked = true },
            onOpenLanguagePicker = { languageClicked = true },
            onInspectAdSlot = { inspectedAd = it },
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("camera_permission_card").assertIsDisplayed()
    composeTestRule.onNodeWithTag("live_cue_readout_card").assertIsDisplayed()
    composeTestRule.onNodeWithTag("header_language_button").assertIsDisplayed().performClick()
    composeTestRule.onNodeWithTag("repeat_audio_cue_button").assertIsDisplayed().performClick()
    composeTestRule.onNodeWithTag("banner_ad_placeholder").assertIsDisplayed().performClick()

    assertTrue(languageClicked)
    assertTrue(repeatClicked)
    assertEquals("banner_radar_bottom_320x50", inspectedAd?.id)
  }

  @Test
  fun `live radar screen dynamically switches to Spanish UI resources`() {
    val baseContext = ApplicationProvider.getApplicationContext<Context>()
    val esContext = baseContext.createLocalizedContext("es")

    composeTestRule.setContent {
      CompositionLocalProvider(
        LocalLocalizedContext provides esContext,
        LocalLayoutDirection provides layoutDirectionForTag("es"),
      ) {
        PathBeaconTheme {
          LiveRadarScreen(
            uiState =
              RadarUiState(
                hasCameraPermission = false,
                currentCueText = esContext.getString(R.string.cue_path_clear),
                highestSeverity = HazardSeverity.CLEAR,
              ),
            localizedContextProvider = { esContext },
            onRequestCameraPermission = {},
            onOpenAppSettings = {},
            onFrameAnalyzed = {},
            onToggleScanning = {},
            onToggleTorch = {},
            onToggleAutoSpeak = {},
            onRepeatAudioCue = {},
            onOpenLanguagePicker = {},
            onInspectAdSlot = {},
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithText("REPETIR AVISO DE VOZ").assertIsDisplayed()
  }

  @Test
  fun `language picker dialog selects Japanese`() {
    val baseContext = ApplicationProvider.getApplicationContext<Context>()
    var selectedTag = ""

    composeTestRule.setContent {
      CompositionLocalProvider(LocalLocalizedContext provides baseContext) {
        PathBeaconTheme {
          ClarityLanguageDialog(
            selectedLanguageTag = "en",
            onSelectLanguage = { selectedTag = it },
            onDismiss = {},
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("lang_option_ja").assertIsDisplayed().performClick()
    assertEquals("ja", selectedTag)
  }

  @Test
  fun `cue log screen displays native ad placeholder and replays cues`() {
    val baseContext = ApplicationProvider.getApplicationContext<Context>()
    var replayedId = -1L

    composeTestRule.setContent {
      CompositionLocalProvider(LocalLocalizedContext provides baseContext) {
        PathBeaconTheme {
          CueLogScreen(
            cueHistory =
              listOf(
                AudioCueEntry(
                  id = 42L,
                  timestampFormatted = "11:05:00",
                  spokenText = "Warning: Person at 12 o'clock, very close.",
                  severity = HazardSeverity.CRITICAL,
                  zoneLabel = "AHEAD",
                )
              ),
            onReplayCue = { replayedId = it.id },
            onClearHistory = {},
            onInspectAdSlot = {},
          )
        }
      }
    }

    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("native_ad_placeholder").assertIsDisplayed()
    composeTestRule.onNodeWithTag("cue_entry_42").assertIsDisplayed()
    composeTestRule.onNodeWithTag("clear_cue_log_button").assertIsDisplayed()
    assertEquals(-1L, replayedId)
  }
}
