package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.audio.CueSpeaker
import com.example.data.PreferencesRepository
import com.example.localization.createLocalizedContext
import com.example.localization.resolveLanguageOption
import com.example.model.AccessibilityPreferences
import com.example.model.AdSlotSpec
import com.example.model.AudioCueEntry
import com.example.model.DetectedObstacle
import com.example.model.HazardSeverity
import com.example.model.HighContrastPalette
import com.example.model.ZoneClearance
import com.example.vision.FrameAnalysisResult
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class RadarUiState(
  val hasCameraPermission: Boolean = false,
  val isScanning: Boolean = true,
  val isTorchEnabled: Boolean = false,
  val obstacles: List<DetectedObstacle> = emptyList(),
  val zoneClearance: ZoneClearance = ZoneClearance(),
  val highestSeverity: HazardSeverity = HazardSeverity.CLEAR,
  val currentCueText: String = "",
  val lastSpokenCueText: String = "",
  val lastCueTimestamp: String = "--:--:--",
  val cueHistory: List<AudioCueEntry> = emptyList(),
  val preferences: AccessibilityPreferences = AccessibilityPreferences(),
  val isSpeaking: Boolean = false,
  val isTtsLanguageAvailable: Boolean = true,
  val activeAdDetail: AdSlotSpec? = null,
  val isLanguageDialogOpen: Boolean = false,
)

class RadarViewModel(application: Application) : AndroidViewModel(application) {

  private val preferencesRepository = PreferencesRepository(application)
  private val cueSpeaker = CueSpeaker(application)
  private val timeFormatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

  @Volatile private var localizedContext: Context = application

  private val _uiState =
    MutableStateFlow(
      RadarUiState(
        currentCueText = application.getString(R.string.cue_ready_initial),
        lastSpokenCueText = application.getString(R.string.cue_last_spoken_initial),
      )
    )
  val uiState: StateFlow<RadarUiState> = _uiState.asStateFlow()

  private var lastAutoAnnounceTimeMs = 0L
  private var lastAnnouncedCue = ""
  private var nextCueId = 1L

  init {
    viewModelScope.launch {
      preferencesRepository.preferencesFlow.collect { prefs ->
        val previousTag = _uiState.value.preferences.languageTag
        localizedContext =
          if (prefs.languageTag.isBlank()) getApplication<Application>()
          else getApplication<Application>().createLocalizedContext(prefs.languageTag)

        cueSpeaker.updateSpeechRate(prefs.speechRate)
        cueSpeaker.updateLanguageTag(prefs.languageTag)

        _uiState.update { state ->
          val updatedCue =
            if (previousTag != prefs.languageTag && state.obstacles.isEmpty()) {
              localizedContext.getString(R.string.cue_ready_initial)
            } else {
              state.currentCueText
            }
          val updatedLastSpoken =
            if (previousTag != prefs.languageTag && state.cueHistory.isEmpty()) {
              localizedContext.getString(R.string.cue_last_spoken_initial)
            } else {
              state.lastSpokenCueText
            }
          state.copy(
            preferences = prefs,
            currentCueText = updatedCue,
            lastSpokenCueText = updatedLastSpoken,
          )
        }
      }
    }
    viewModelScope.launch {
      cueSpeaker.isSpeaking.collect { speaking ->
        _uiState.update { it.copy(isSpeaking = speaking) }
      }
    }
    viewModelScope.launch {
      cueSpeaker.isTtsLanguageAvailable.collect { available ->
        _uiState.update { it.copy(isTtsLanguageAvailable = available) }
      }
    }
  }

  fun currentLocalizedContext(): Context = localizedContext

  fun onCameraPermissionChanged(granted: Boolean) {
    _uiState.update { it.copy(hasCameraPermission = granted) }
  }

  fun toggleScanning() {
    val nowScanning = !_uiState.value.isScanning
    _uiState.update {
      it.copy(
        isScanning = nowScanning,
        obstacles = if (nowScanning) it.obstacles else emptyList(),
        currentCueText =
          if (nowScanning) localizedContext.getString(R.string.cue_radar_resumed_ui)
          else localizedContext.getString(R.string.cue_radar_paused_ui),
      )
    }
    if (!nowScanning) {
      cueSpeaker.stopSpeaking()
    } else if (_uiState.value.preferences.autoSpeakEnabled) {
      cueSpeaker.speakCue(
        localizedContext.getString(R.string.cue_radar_resumed_spoken),
        interrupt = true,
      )
    }
  }

  fun toggleTorch() {
    _uiState.update { it.copy(isTorchEnabled = !it.isTorchEnabled) }
  }

  fun toggleAutoSpeak() {
    val newValue = !_uiState.value.preferences.autoSpeakEnabled
    viewModelScope.launch { preferencesRepository.setAutoSpeakEnabled(newValue) }
    if (!newValue) {
      cueSpeaker.stopSpeaking()
    } else {
      cueSpeaker.speakCue(
        localizedContext.getString(R.string.cue_auto_voice_enabled_spoken),
        interrupt = true,
      )
    }
  }

  fun onFrameAnalyzed(result: FrameAnalysisResult) {
    val state = _uiState.value
    if (!state.isScanning) return

    val now = System.currentTimeMillis()
    val timestamp = timeFormatter.format(Date(now))

    _uiState.update {
      it.copy(
        obstacles = result.obstacles,
        zoneClearance = result.zoneClearance,
        highestSeverity = result.highestSeverity,
        currentCueText = result.primaryCueText,
      )
    }

    val intervalMs = state.preferences.repeatIntervalSeconds * 1000L
    val isNewHazard =
      result.primaryCueText != lastAnnouncedCue &&
        result.highestSeverity != HazardSeverity.CLEAR
    val isCriticalUrgent =
      result.highestSeverity == HazardSeverity.CRITICAL &&
        now - lastAutoAnnounceTimeMs >= 2000L
    val intervalElapsed = now - lastAutoAnnounceTimeMs >= intervalMs

    val shouldAnnounce =
      (result.highestSeverity != HazardSeverity.CLEAR &&
        (isNewHazard || isCriticalUrgent || intervalElapsed)) ||
        (result.highestSeverity == HazardSeverity.CLEAR &&
          lastAnnouncedCue != result.primaryCueText &&
          intervalElapsed)

    if (shouldAnnounce) {
      lastAutoAnnounceTimeMs = now
      lastAnnouncedCue = result.primaryCueText
      recordAndSpeakCue(
        cueText = result.primaryCueText,
        severity = result.highestSeverity,
        zoneLabel = result.primaryZoneLabel,
        timestamp = timestamp,
        speak = state.preferences.autoSpeakEnabled,
        vibrate = state.preferences.hapticAlertsEnabled && result.highestSeverity != HazardSeverity.CLEAR,
      )
    }
  }

  fun onRepeatAudioCueClicked() {
    val state = _uiState.value
    val cueToRepeat = state.currentCueText.ifBlank { state.lastSpokenCueText }
    val timestamp = timeFormatter.format(Date())

    recordAndSpeakCue(
      cueText = cueToRepeat,
      severity = state.highestSeverity,
      zoneLabel = localizedContext.getString(R.string.zone_label_repeat),
      timestamp = timestamp,
      speak = true,
      vibrate = state.preferences.hapticAlertsEnabled,
    )
  }

  fun replayHistoricalCue(entry: AudioCueEntry) {
    cueSpeaker.speakCue(entry.spokenText, interrupt = true)
    if (_uiState.value.preferences.hapticAlertsEnabled) {
      cueSpeaker.triggerHaptic(entry.severity)
    }
    _uiState.update {
      it.copy(
        lastSpokenCueText = entry.spokenText,
        lastCueTimestamp = timeFormatter.format(Date()),
      )
    }
  }

  fun clearCueHistory() {
    _uiState.update { it.copy(cueHistory = emptyList()) }
  }

  fun setSpeechRate(rate: Float) {
    viewModelScope.launch { preferencesRepository.setSpeechRate(rate) }
  }

  fun setHapticAlertsEnabled(enabled: Boolean) {
    viewModelScope.launch { preferencesRepository.setHapticAlertsEnabled(enabled) }
  }

  fun setRepeatIntervalSeconds(seconds: Int) {
    viewModelScope.launch { preferencesRepository.setRepeatIntervalSeconds(seconds) }
  }

  fun setHighContrastPalette(palette: HighContrastPalette) {
    viewModelScope.launch { preferencesRepository.setHighContrastPalette(palette) }
  }

  fun openLanguageDialog() {
    _uiState.update { it.copy(isLanguageDialogOpen = true) }
  }

  fun dismissLanguageDialog() {
    _uiState.update { it.copy(isLanguageDialogOpen = false) }
  }

  fun selectLanguage(languageTag: String) {
    val newCtx =
      if (languageTag.isBlank()) getApplication<Application>()
      else getApplication<Application>().createLocalizedContext(languageTag)
    localizedContext = newCtx
    cueSpeaker.updateLanguageTag(languageTag)

    val languageDisplayName =
      if (languageTag.isBlank()) newCtx.getString(R.string.language_system_default)
      else resolveLanguageOption(languageTag).nativeName

    val confirmationCue =
      newCtx.getString(R.string.language_changed_spoken, languageDisplayName)

    lastAnnouncedCue = ""
    _uiState.update {
      it.copy(
        isLanguageDialogOpen = false,
        currentCueText = newCtx.getString(R.string.cue_ready_initial),
        lastSpokenCueText = confirmationCue,
      )
    }

    viewModelScope.launch { preferencesRepository.setLanguageTag(languageTag) }
    cueSpeaker.speakCue(confirmationCue, interrupt = true)
  }

  fun testVoiceAndHaptic() {
    val testPhrase = localizedContext.getString(R.string.cue_test_phrase)
    cueSpeaker.speakCue(testPhrase, interrupt = true)
    if (_uiState.value.preferences.hapticAlertsEnabled) {
      cueSpeaker.triggerHaptic(HazardSeverity.CAUTION)
    }
  }

  fun openAdSlotDetail(spec: AdSlotSpec) {
    _uiState.update { it.copy(activeAdDetail = spec) }
  }

  fun dismissAdSlotDetail() {
    _uiState.update { it.copy(activeAdDetail = null) }
  }

  private fun recordAndSpeakCue(
    cueText: String,
    severity: HazardSeverity,
    zoneLabel: String,
    timestamp: String,
    speak: Boolean,
    vibrate: Boolean,
  ) {
    if (speak) {
      cueSpeaker.speakCue(cueText, interrupt = true)
    }
    if (vibrate) {
      cueSpeaker.triggerHaptic(severity)
    }

    val entry =
      AudioCueEntry(
        id = nextCueId++,
        timestampFormatted = timestamp,
        spokenText = cueText,
        severity = severity,
        zoneLabel = zoneLabel,
      )

    _uiState.update { current ->
      current.copy(
        lastSpokenCueText = cueText,
        lastCueTimestamp = timestamp,
        cueHistory = (listOf(entry) + current.cueHistory).take(50),
      )
    }
  }

  override fun onCleared() {
    super.onCleared()
    cueSpeaker.release()
  }
}
