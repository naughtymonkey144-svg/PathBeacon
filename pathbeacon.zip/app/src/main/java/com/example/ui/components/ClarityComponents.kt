package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.localization.SUPPORTED_LANGUAGES
import com.example.localization.localizedString
import com.example.model.AdSlotSpec
import com.example.model.HazardSeverity
import com.example.ui.theme.CanvasBlack
import com.example.ui.theme.LocalClarityTokens
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftWhiteText
import com.example.ui.theme.SurfaceCharcoal
import com.example.ui.theme.SurfaceContainer

@Composable
fun ClarityStatusPill(
  text: String,
  accentColor: Color,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier =
      modifier
        .clip(CircleShape)
        .background(CanvasBlack)
        .border(width = 2.dp, color = accentColor, shape = CircleShape)
        .padding(horizontal = 12.dp, vertical = 6.dp),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = text,
      style = MaterialTheme.typography.labelSmall,
      color = accentColor,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
fun severityColor(severity: HazardSeverity): Color {
  val tokens = LocalClarityTokens.current
  return when (severity) {
    HazardSeverity.CRITICAL -> tokens.criticalHazard
    HazardSeverity.CAUTION -> tokens.primaryFocus
    HazardSeverity.INFO -> tokens.secondaryAction
    HazardSeverity.CLEAR -> tokens.positiveSignal
  }
}

@Composable
fun ClarityPrimaryButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  icon: ImageVector? = null,
  contentDescriptionText: String = text,
  minHeightDp: Int = 56,
  containerColor: Color = LocalClarityTokens.current.primaryFocus,
  contentColor: Color = LocalClarityTokens.current.onPrimaryFocus,
) {
  Button(
    onClick = onClick,
    modifier =
      modifier
        .fillMaxWidth()
        .heightIn(min = minHeightDp.dp)
        .semantics { contentDescription = contentDescriptionText },
    shape = RoundedCornerShape(4.dp),
    colors =
      ButtonDefaults.buttonColors(
        containerColor = containerColor,
        contentColor = contentColor,
      ),
    border = BorderStroke(3.dp, containerColor),
    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
  ) {
    if (icon != null) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        modifier = Modifier.size(26.dp),
      )
      Spacer(modifier = Modifier.width(12.dp))
    }
    Text(
      text = text,
      style = MaterialTheme.typography.labelLarge,
      fontWeight = FontWeight.ExtraBold,
      maxLines = 2,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
fun ClaritySecondaryButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  icon: ImageVector? = null,
  accentColor: Color = LocalClarityTokens.current.secondaryAction,
  minHeightDp: Int = 56,
) {
  OutlinedButton(
    onClick = onClick,
    modifier = modifier.heightIn(min = minHeightDp.dp),
    shape = RoundedCornerShape(4.dp),
    colors =
      ButtonDefaults.outlinedButtonColors(
        containerColor = CanvasBlack,
        contentColor = accentColor,
      ),
    border = BorderStroke(3.dp, accentColor),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
  ) {
    if (icon != null) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        modifier = Modifier.size(22.dp),
      )
      Spacer(modifier = Modifier.width(8.dp))
    }
    Text(
      text = text,
      style = MaterialTheme.typography.labelMedium,
      fontWeight = FontWeight.Bold,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
fun ClarityDestructiveButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val hazardColor = LocalClarityTokens.current.criticalHazard
  OutlinedButton(
    onClick = onClick,
    modifier = modifier.heightIn(min = 56.dp),
    shape = RoundedCornerShape(4.dp),
    colors =
      ButtonDefaults.outlinedButtonColors(
        containerColor = CanvasBlack,
        contentColor = PureWhite,
      ),
    border = BorderStroke(3.dp, hazardColor),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
  ) {
    Icon(
      imageVector = Icons.Filled.Close,
      contentDescription = null,
      tint = hazardColor,
      modifier = Modifier.size(20.dp),
    )
    Spacer(modifier = Modifier.width(8.dp))
    Text(
      text = "[X] $text",
      style = MaterialTheme.typography.labelMedium,
      color = PureWhite,
      maxLines = 1,
    )
  }
}

@Composable
fun AdPlaceholderBanner(
  onInspectAdSlot: (AdSlotSpec) -> Unit,
  modifier: Modifier = Modifier,
) {
  val tokens = LocalClarityTokens.current
  val bannerTitle = localizedString(R.string.ad_banner_title)
  val spec =
    AdSlotSpec(
      id = "banner_radar_bottom_320x50",
      title = bannerTitle,
      formatLabel = localizedString(R.string.ad_banner_format),
      dimensionsLabel = localizedString(R.string.ad_banner_dimensions),
      placementNotes = localizedString(R.string.ad_banner_notes),
    )
  val a11yBannerDesc = localizedString(R.string.ad_a11y_banner, bannerTitle)

  Box(
    modifier =
      modifier
        .fillMaxWidth()
        .heightIn(min = 60.dp)
        .testTag("banner_ad_placeholder")
        .clip(RoundedCornerShape(4.dp))
        .background(SurfaceCharcoal)
        .clickable(
          role = Role.Button,
          onClickLabel = localizedString(R.string.ad_learn_more),
          onClick = { onInspectAdSlot(spec) },
        )
        .semantics { contentDescription = a11yBannerDesc }
  ) {
    androidx.compose.foundation.Canvas(modifier = Modifier.matchParentSize()) {
      drawRoundRect(
        color = tokens.secondaryAction,
        style =
          Stroke(
            width = 2.dp.toPx(),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f, 10f), 0f),
          ),
      )
    }

    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      ClarityStatusPill(
        text = localizedString(R.string.ad_badge_label),
        accentColor = tokens.secondaryAction,
      )
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = spec.title.uppercase(),
          style = MaterialTheme.typography.labelMedium,
          color = PureWhite,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = localizedString(R.string.ad_banner_subtitle),
          style = MaterialTheme.typography.bodyMedium,
          color = SoftWhiteText,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
      Icon(
        imageVector = Icons.Filled.Info,
        contentDescription = null,
        tint = tokens.secondaryAction,
        modifier = Modifier.size(22.dp),
      )
    }
  }
}

@Composable
fun AdPlaceholderNativeCard(
  onInspectAdSlot: (AdSlotSpec) -> Unit,
  modifier: Modifier = Modifier,
) {
  val tokens = LocalClarityTokens.current
  val nativeTitle = localizedString(R.string.ad_native_title)
  val spec =
    AdSlotSpec(
      id = "native_cue_log_card",
      title = nativeTitle,
      formatLabel = localizedString(R.string.ad_native_format),
      dimensionsLabel = localizedString(R.string.ad_native_dimensions),
      placementNotes = localizedString(R.string.ad_native_notes),
    )

  Surface(
    modifier =
      modifier
        .fillMaxWidth()
        .testTag("native_ad_placeholder"),
    shape = RoundedCornerShape(4.dp),
    color = SurfaceContainer,
    border = BorderStroke(3.dp, PureWhite),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          ClarityStatusPill(
            text = localizedString(R.string.ad_badge_label),
            accentColor = tokens.primaryFocus,
          )
          Text(
            text = localizedString(R.string.ad_placeholder_label),
            style = MaterialTheme.typography.labelMedium,
            color = tokens.primaryFocus,
          )
        }
        Icon(
          imageVector = Icons.Filled.Campaign,
          contentDescription = null,
          tint = tokens.secondaryAction,
          modifier = Modifier.size(24.dp),
        )
      }

      Text(
        text = spec.title,
        style = MaterialTheme.typography.titleMedium,
        color = PureWhite,
      )
      Text(
        text = localizedString(R.string.ad_native_body),
        style = MaterialTheme.typography.bodyMedium,
        color = SoftWhiteText,
      )

      ClaritySecondaryButton(
        text = localizedString(R.string.ad_learn_more),
        onClick = { onInspectAdSlot(spec) },
        icon = Icons.Filled.Info,
        modifier = Modifier.fillMaxWidth(),
      )
    }
  }
}

@Composable
fun AdSlotDetailDialog(
  spec: AdSlotSpec,
  onDismiss: () -> Unit,
) {
  val tokens = LocalClarityTokens.current
  Dialog(onDismissRequest = onDismiss) {
    Box(modifier = Modifier.fillMaxWidth().padding(6.dp)) {
      Box(
        modifier =
          Modifier.matchParentSize()
            .offset(x = 6.dp, y = 6.dp)
            .background(CanvasBlack, RoundedCornerShape(8.dp))
            .border(2.dp, PureWhite, RoundedCornerShape(8.dp))
      )
      Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        color = CanvasBlack,
        border = BorderStroke(4.dp, tokens.primaryFocus),
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            ClarityStatusPill(
              text = localizedString(R.string.ad_badge_label),
              accentColor = tokens.primaryFocus,
            )
            Text(
              text = localizedString(R.string.ad_slot_details_title),
              style = MaterialTheme.typography.titleLarge,
              color = PureWhite,
              modifier = Modifier.semantics { heading() },
            )
          }

          Text(
            text = spec.title,
            style = MaterialTheme.typography.titleMedium,
            color = tokens.primaryFocus,
          )
          DetailLine(label = localizedString(R.string.ad_slot_id_label), value = spec.id)
          DetailLine(label = localizedString(R.string.ad_slot_format_label), value = spec.formatLabel)
          DetailLine(label = localizedString(R.string.ad_slot_dimensions_label), value = spec.dimensionsLabel)
          Text(
            text = spec.placementNotes,
            style = MaterialTheme.typography.bodyMedium,
            color = SoftWhiteText,
          )

          Spacer(modifier = Modifier.height(4.dp))
          ClarityPrimaryButton(
            text = localizedString(R.string.close_ad_preview),
            onClick = onDismiss,
            modifier = Modifier.testTag("close_ad_dialog_button"),
          )
        }
      }
    }
  }
}

@Composable
fun ClarityLanguageDialog(
  selectedLanguageTag: String,
  onSelectLanguage: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  val tokens = LocalClarityTokens.current
  Dialog(onDismissRequest = onDismiss) {
    Box(modifier = Modifier.fillMaxWidth().padding(6.dp)) {
      Box(
        modifier =
          Modifier.matchParentSize()
            .offset(x = 6.dp, y = 6.dp)
            .background(CanvasBlack, RoundedCornerShape(8.dp))
            .border(2.dp, PureWhite, RoundedCornerShape(8.dp))
      )
      Surface(
        modifier = Modifier.fillMaxWidth().testTag("language_picker_dialog"),
        shape = RoundedCornerShape(8.dp),
        color = CanvasBlack,
        border = BorderStroke(4.dp, tokens.primaryFocus),
      ) {
        Column(
          modifier = Modifier.padding(20.dp).verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.Translate,
              contentDescription = null,
              tint = tokens.primaryFocus,
              modifier = Modifier.size(26.dp),
            )
            Text(
              text = localizedString(R.string.language_dialog_title),
              style = MaterialTheme.typography.titleLarge,
              color = PureWhite,
              modifier = Modifier.semantics { heading() },
            )
          }

          SUPPORTED_LANGUAGES.forEach { lang ->
            val selected = selectedLanguageTag == lang.tag
            val displayLabel =
              if (lang.tag.isBlank()) localizedString(R.string.language_system_default)
              else lang.nativeName
            val bgColor = if (selected) tokens.primaryFocus else SurfaceCharcoal
            val fgColor = if (selected) tokens.onPrimaryFocus else PureWhite
            val borderColor = if (selected) tokens.primaryFocus else PureWhite
            val prefix = if (selected) "[●]" else "[${lang.shortCode}]"

            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .heightIn(min = 56.dp)
                  .testTag("lang_option_${lang.tag.ifBlank { "system" }}")
                  .clip(RoundedCornerShape(4.dp))
                  .background(bgColor)
                  .border(2.dp, borderColor, RoundedCornerShape(4.dp))
                  .clickable(role = Role.RadioButton) { onSelectLanguage(lang.tag) }
                  .padding(horizontal = 14.dp, vertical = 12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(
                text = displayLabel,
                style = MaterialTheme.typography.titleMedium,
                color = fgColor,
              )
              Text(
                text = prefix,
                style = MaterialTheme.typography.labelMedium,
                color = fgColor,
              )
            }
          }

          Spacer(modifier = Modifier.height(4.dp))
          ClaritySecondaryButton(
            text = localizedString(R.string.close_dialog),
            onClick = onDismiss,
            modifier = Modifier.fillMaxWidth().testTag("close_language_dialog_button"),
          )
        }
      }
    }
  }
}

@Composable
private fun DetailLine(label: String, value: String) {
  Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = LocalClarityTokens.current.secondaryAction,
    )
    Text(
      text = value,
      style = MaterialTheme.typography.bodyMedium,
      color = PureWhite,
    )
  }
}
