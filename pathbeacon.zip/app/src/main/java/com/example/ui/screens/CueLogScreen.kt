package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.localization.localizedString
import com.example.model.AdSlotSpec
import com.example.model.AudioCueEntry
import com.example.ui.components.AdPlaceholderNativeCard
import com.example.ui.components.ClarityDestructiveButton
import com.example.ui.components.ClaritySecondaryButton
import com.example.ui.components.ClarityStatusPill
import com.example.ui.components.severityColor
import com.example.ui.theme.CanvasBlack
import com.example.ui.theme.LocalClarityTokens
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftWhiteText
import com.example.ui.theme.SurfaceCharcoal

@Composable
fun CueLogScreen(
  cueHistory: List<AudioCueEntry>,
  onReplayCue: (AudioCueEntry) -> Unit,
  onClearHistory: () -> Unit,
  onInspectAdSlot: (AdSlotSpec) -> Unit,
  modifier: Modifier = Modifier,
) {
  val tokens = LocalClarityTokens.current

  Column(
    modifier = modifier.fillMaxSize().background(CanvasBlack).padding(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Column {
        Text(
          text = localizedString(R.string.cue_log_title),
          style = MaterialTheme.typography.headlineSmall,
          color = PureWhite,
          modifier = Modifier.semantics { heading() },
        )
        Text(
          text = localizedString(R.string.cue_log_count, cueHistory.size),
          style = MaterialTheme.typography.bodyMedium,
          color = SoftWhiteText,
        )
      }
      if (cueHistory.isNotEmpty()) {
        ClarityDestructiveButton(
          text = localizedString(R.string.clear_cue_log),
          onClick = onClearHistory,
          modifier = Modifier.testTag("clear_cue_log_button"),
        )
      }
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize().testTag("cue_log_list"),
      contentPadding = PaddingValues(bottom = 16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item(key = "native_ad_slot") {
        AdPlaceholderNativeCard(onInspectAdSlot = onInspectAdSlot)
      }

      if (cueHistory.isEmpty()) {
        item(key = "empty_cue_state") {
          Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(4.dp),
            color = SurfaceCharcoal,
            border = BorderStroke(3.dp, tokens.secondaryAction),
          ) {
            Column(
              modifier = Modifier.padding(24.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              Icon(
                imageVector = Icons.Filled.History,
                contentDescription = null,
                tint = tokens.secondaryAction,
                modifier = Modifier.size(44.dp),
              )
              Text(
                text = localizedString(R.string.empty_cue_log_title),
                style = MaterialTheme.typography.titleLarge,
                color = PureWhite,
              )
              Text(
                text = localizedString(R.string.empty_cue_log_body),
                style = MaterialTheme.typography.bodyMedium,
                color = SoftWhiteText,
              )
            }
          }
        }
      } else {
        items(items = cueHistory, key = { it.id }) { entry ->
          CueHistoryCard(
            entry = entry,
            onReplay = { onReplayCue(entry) },
          )
        }
      }
    }
  }
}

@Composable
private fun CueHistoryCard(
  entry: AudioCueEntry,
  onReplay: () -> Unit,
) {
  val accentColor = severityColor(entry.severity)
  Surface(
    modifier = Modifier.fillMaxWidth().testTag("cue_entry_${entry.id}"),
    shape = RoundedCornerShape(4.dp),
    color = SurfaceCharcoal,
    border = BorderStroke(2.dp, accentColor),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        ClarityStatusPill(
          text = "${entry.severity.badgePrefix} ${entry.zoneLabel}",
          accentColor = accentColor,
        )
        Text(
          text = entry.timestampFormatted,
          style = MaterialTheme.typography.labelMedium,
          color = SoftWhiteText,
        )
      }

      Text(
        text = entry.spokenText,
        style = MaterialTheme.typography.titleMedium,
        color = PureWhite,
      )

      ClaritySecondaryButton(
        text = localizedString(R.string.speak_cue_again),
        onClick = onReplay,
        icon = Icons.AutoMirrored.Filled.VolumeUp,
        accentColor = accentColor,
        modifier = Modifier.fillMaxWidth(),
      )
    }
  }
}
