package com.example.ui.components

import android.content.Context
import android.view.ViewGroup
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.R
import com.example.localization.LocalLocalizedContext
import com.example.localization.localizedString
import com.example.model.DetectedObstacle
import com.example.model.HazardSeverity
import com.example.model.ZoneClearance
import com.example.ui.theme.CanvasBlack
import com.example.ui.theme.LocalClarityTokens
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SurfaceCharcoal
import com.example.vision.FrameAnalysisResult
import com.example.vision.ObstacleFrameAnalyzer
import java.util.concurrent.Executors
import kotlin.math.roundToInt

@Composable
fun CameraObstacleViewport(
  isScanning: Boolean,
  isTorchEnabled: Boolean,
  obstacles: List<DetectedObstacle>,
  zoneClearance: ZoneClearance,
  highestSeverity: HazardSeverity,
  localizedContextProvider: () -> Context,
  onFrameAnalyzed: (FrameAnalysisResult) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val localizedContext = LocalLocalizedContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val tokens = LocalClarityTokens.current
  val latestContextProvider by rememberUpdatedState(localizedContextProvider)

  var cameraErrorText by remember { mutableStateOf<String?>(null) }
  var boundCamera by remember { mutableStateOf<Camera?>(null) }

  val analysisExecutor = remember { Executors.newSingleThreadExecutor() }
  val analyzer = remember {
    ObstacleFrameAnalyzer(
      contextProvider = { latestContextProvider() },
      onAnalysisResult = onFrameAnalyzed,
    )
  }

  LaunchedEffect(isScanning) { analyzer.setPaused(!isScanning) }

  LaunchedEffect(isTorchEnabled, boundCamera) {
    val cam = boundCamera
    if (cam != null && cam.cameraInfo.hasFlashUnit()) {
      cam.cameraControl.enableTorch(isTorchEnabled)
    }
  }

  DisposableEffect(Unit) {
    onDispose {
      analyzer.close()
      analysisExecutor.shutdown()
    }
  }

  val frameBorderColor =
    if (!isScanning) tokens.primaryFocus else severityColor(highestSeverity)

  val viewportA11yDesc =
    when {
      !isScanning -> localizedString(R.string.camera_a11y_paused)
      obstacles.isEmpty() -> localizedString(R.string.camera_a11y_clear)
      else -> localizedString(R.string.camera_a11y_detected, obstacles.size)
    }

  Column(
    modifier = modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    BoxWithConstraints(
      modifier =
        Modifier.fillMaxWidth()
          .weight(1f)
          .testTag("camera_obstacle_viewport")
          .clip(RoundedCornerShape(4.dp))
          .background(CanvasBlack)
          .border(3.dp, frameBorderColor, RoundedCornerShape(4.dp))
          .semantics { contentDescription = viewportA11yDesc }
    ) {
      val viewportWidthPx = with(LocalDensity.current) { maxWidth.toPx() }
      val viewportHeightPx = with(LocalDensity.current) { maxHeight.toPx() }

      AndroidView(
        factory = { viewContext ->
          PreviewView(viewContext).apply {
            layoutParams =
              ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
              )
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
          }
        },
        modifier = Modifier.fillMaxSize(),
        update = { previewView ->
          val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
          cameraProviderFuture.addListener(
            {
              try {
                val cameraProvider = cameraProviderFuture.get()
                val preview =
                  Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                  }
                val imageAnalysis =
                  ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also { it.setAnalyzer(analysisExecutor, analyzer) }

                val selector =
                  when {
                    cameraProvider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA) ->
                      CameraSelector.DEFAULT_BACK_CAMERA
                    cameraProvider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA) ->
                      CameraSelector.DEFAULT_FRONT_CAMERA
                    else -> null
                  }

                if (selector == null) {
                  cameraErrorText = localizedContext.getString(R.string.camera_unavailable)
                } else {
                  cameraProvider.unbindAll()
                  boundCamera =
                    cameraProvider.bindToLifecycle(
                      lifecycleOwner,
                      selector,
                      preview,
                      imageAnalysis,
                    )
                  cameraErrorText = null
                }
              } catch (e: Exception) {
                cameraErrorText =
                  e.localizedMessage ?: localizedContext.getString(R.string.camera_start_error)
              }
            },
            ContextCompat.getMainExecutor(context),
          )
        },
      )

      Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val strokePx = 3.dp.toPx()

        val guideDash = PathEffect.dashPathEffect(floatArrayOf(14f, 14f), 0f)
        drawLine(
          color = PureWhite.copy(alpha = 0.55f),
          start = Offset(w * 0.33f, 0f),
          end = Offset(w * 0.33f, h),
          strokeWidth = 1.5.dp.toPx(),
          pathEffect = guideDash,
        )
        drawLine(
          color = PureWhite.copy(alpha = 0.55f),
          start = Offset(w * 0.67f, 0f),
          end = Offset(w * 0.67f, h),
          strokeWidth = 1.5.dp.toPx(),
          pathEffect = guideDash,
        )

        val bracket = 26.dp.toPx()
        val inset = 10.dp.toPx()
        drawLine(frameBorderColor, Offset(inset, inset), Offset(inset + bracket, inset), strokePx)
        drawLine(frameBorderColor, Offset(inset, inset), Offset(inset, inset + bracket), strokePx)
        drawLine(frameBorderColor, Offset(w - inset, inset), Offset(w - inset - bracket, inset), strokePx)
        drawLine(frameBorderColor, Offset(w - inset, inset), Offset(w - inset, inset + bracket), strokePx)
        drawLine(frameBorderColor, Offset(inset, h - inset), Offset(inset + bracket, h - inset), strokePx)
        drawLine(frameBorderColor, Offset(inset, h - inset), Offset(inset, h - inset - bracket), strokePx)
        drawLine(frameBorderColor, Offset(w - inset, h - inset), Offset(w - inset - bracket, h - inset), strokePx)
        drawLine(frameBorderColor, Offset(w - inset, h - inset), Offset(w - inset, h - inset - bracket), strokePx)

        if (isScanning) {
          for (obstacle in obstacles) {
            val boxColor =
              when (obstacle.severity) {
                HazardSeverity.CRITICAL -> tokens.criticalHazard
                HazardSeverity.CAUTION -> tokens.primaryFocus
                HazardSeverity.INFO -> tokens.secondaryAction
                HazardSeverity.CLEAR -> tokens.positiveSignal
              }
            val left = obstacle.leftNorm * w
            val top = obstacle.topNorm * h
            val boxW = ((obstacle.rightNorm - obstacle.leftNorm) * w).coerceAtLeast(24f)
            val boxH = ((obstacle.bottomNorm - obstacle.topNorm) * h).coerceAtLeast(24f)

            drawRect(
              color = boxColor,
              topLeft = Offset(left, top),
              size = Size(boxW, boxH),
              style = Stroke(width = 3.5.dp.toPx()),
            )
          }
        }
      }

      if (isScanning) {
        obstacles.forEach { obstacle ->
          val tagColor = severityColor(obstacle.severity)
          val textColor =
            if (obstacle.severity == HazardSeverity.CRITICAL) PureWhite else CanvasBlack
          val xPx =
            (obstacle.leftNorm * viewportWidthPx)
              .roundToInt()
              .coerceIn(8, (viewportWidthPx - 180f).roundToInt().coerceAtLeast(8))
          val yPx =
            ((obstacle.topNorm * viewportHeightPx) - 36f)
              .roundToInt()
              .coerceIn(8, (viewportHeightPx - 44f).roundToInt().coerceAtLeast(8))

          val zoneText = localizedString(obstacle.zone.labelRes)
          Box(
            modifier =
              Modifier.offset { IntOffset(xPx, yPx) }
                .background(tagColor, RoundedCornerShape(4.dp))
                .border(2.dp, CanvasBlack, RoundedCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = "${obstacle.severity.badgePrefix} ${obstacle.label.uppercase()} • $zoneText",
              style = MaterialTheme.typography.labelSmall,
              color = textColor,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }

      val hudBadgeText =
        when {
          !isScanning -> localizedString(R.string.hud_radar_paused)
          obstacles.isEmpty() ->
            localizedString(R.string.hud_scanning, highestSeverity.badgePrefix)
          else ->
            localizedString(
              R.string.hud_detected_count,
              highestSeverity.badgePrefix,
              obstacles.size,
            )
        }

      Box(
        modifier =
          Modifier.align(Alignment.TopStart)
            .padding(10.dp)
            .background(CanvasBlack, RoundedCornerShape(4.dp))
            .border(2.dp, frameBorderColor, RoundedCornerShape(4.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
      ) {
        Text(
          text = hudBadgeText,
          style = MaterialTheme.typography.labelSmall,
          color = frameBorderColor,
        )
      }

      if (cameraErrorText != null) {
        Box(
          modifier =
            Modifier.align(Alignment.Center)
              .padding(20.dp)
              .background(SurfaceCharcoal, RoundedCornerShape(4.dp))
              .border(3.dp, tokens.primaryFocus, RoundedCornerShape(4.dp))
              .padding(16.dp)
        ) {
          Text(
            text = cameraErrorText ?: "",
            style = MaterialTheme.typography.bodyMedium,
            color = PureWhite,
          )
        }
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth().testTag("corridor_clearance_strip"),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      CorridorZoneMeter(
        zoneTitle = localizedString(R.string.corridor_left_title),
        obstacleLoad = if (isScanning) zoneClearance.leftObstacleLoad else 0f,
        modifier = Modifier.weight(1f),
      )
      CorridorZoneMeter(
        zoneTitle = localizedString(R.string.corridor_center_title),
        obstacleLoad = if (isScanning) zoneClearance.centerObstacleLoad else 0f,
        modifier = Modifier.weight(1f),
      )
      CorridorZoneMeter(
        zoneTitle = localizedString(R.string.corridor_right_title),
        obstacleLoad = if (isScanning) zoneClearance.rightObstacleLoad else 0f,
        modifier = Modifier.weight(1f),
      )
    }
  }
}

@Composable
private fun CorridorZoneMeter(
  zoneTitle: String,
  obstacleLoad: Float,
  modifier: Modifier = Modifier,
) {
  val tokens = LocalClarityTokens.current
  val statusColor =
    when {
      obstacleLoad >= 0.72f -> tokens.criticalHazard
      obstacleLoad >= 0.45f -> tokens.primaryFocus
      else -> tokens.positiveSignal
    }
  val statusWord =
    when {
      obstacleLoad >= 0.72f -> localizedString(R.string.clearance_blocked)
      obstacleLoad >= 0.45f -> localizedString(R.string.clearance_caution)
      else -> localizedString(R.string.clearance_clear)
    }

  Column(
    modifier =
      modifier
        .background(SurfaceCharcoal, RoundedCornerShape(4.dp))
        .border(2.dp, statusColor, RoundedCornerShape(4.dp))
        .padding(horizontal = 8.dp, vertical = 6.dp),
    verticalArrangement = Arrangement.spacedBy(4.dp),
  ) {
    Text(
      text = zoneTitle,
      style = MaterialTheme.typography.labelSmall,
      color = PureWhite,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
    Box(
      modifier =
        Modifier.fillMaxWidth()
          .height(8.dp)
          .background(CanvasBlack, RoundedCornerShape(2.dp))
          .border(1.dp, PureWhite, RoundedCornerShape(2.dp))
    ) {
      Box(
        modifier =
          Modifier.fillMaxWidth(fraction = obstacleLoad.coerceIn(0.08f, 1f))
            .height(8.dp)
            .background(statusColor, RoundedCornerShape(2.dp))
      )
    }
    Text(
      text = statusWord,
      style = MaterialTheme.typography.labelSmall,
      color = statusColor,
      maxLines = 1,
    )
  }
}
