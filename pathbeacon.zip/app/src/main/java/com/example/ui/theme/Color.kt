package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clarity Spectrum High-Contrast Palette
val CanvasBlack = Color(0xFF000000)
val SurfaceCharcoal = Color(0xFF131313)
val SurfaceContainerLow = Color(0xFF1B1B1B)
val SurfaceContainer = Color(0xFF1F1F1F)
val SurfaceContainerHigh = Color(0xFF2A2A2A)
val SurfaceContainerHighest = Color(0xFF353535)

val PureWhite = Color(0xFFFFFFFF)
val SoftWhiteText = Color(0xFFE2E2E2)
val WarmVariantText = Color(0xFFCDC7AA)
val OutlineWarm = Color(0xFF979177)
val OutlineMuted = Color(0xFF4B4731)

// Semantic High-Visibility Accents
val SafetyYellow = Color(0xFFFFE600)
val SafetyYellowContainer = Color(0xFFFDE400)
val OnSafetyYellow = Color(0xFF000000)

val ElectricCyan = Color(0xFF00F0FF)
val ElectricCyanContainer = Color(0xFF00EEFC)
val OnElectricCyan = Color(0xFF000000)

val EmeraldSignal = Color(0xFF00FF88)
val EmeraldSignalContainer = Color(0xFF60FF99)
val OnEmeraldSignal = Color(0xFF00210C)

val CrimsonHazard = Color(0xFFFF3B30)
val CrimsonErrorSoft = Color(0xFFFFB4AB)
val CrimsonContainer = Color(0xFF93000A)
val OnCrimson = Color(0xFFFFFFFF)
