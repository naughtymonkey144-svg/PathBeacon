package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.localization.localizedString
import com.example.localization.resolveShortBadge
import com.example.model.AdSlotSpec
import com.example.model.HazardSeverity
import com.example.ui.RadarUiState
import com.example.ui.components.AdPlaceholderBanner
import com.example.ui.components.CameraObstacleViewport
import com.example.ui.components.ClarityPrimaryButton
import com.example.ui.components.ClaritySecondaryButton
import com.example.ui.components.ClarityStatusPill
import com.example.ui.components.severityColor
import com.example.ui.theme.CanvasBlack
import com.example.ui.theme.LocalClarityTokens
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftWhiteText
import com.example.ui.theme.SurfaceCharcoal
import com.example.vision.FrameAnalysisResult

@Composable
fun LiveRadarScreen(
  uiState: RadarUiState,
  localizedContextProvider: () -> Context,
  onRequestCameraPermission: () -> Unit,
  onOpenAppSettings: () -> Unit,
  onFrameAnalyzed: (FrameAnalysisResult) -> Unit,
  onToggleScanning: () -> Unit,
  onToggleTorch: () -> Unit,
  onToggleAutoSpeak: () -> Unit,
  onRepeatAudioCue: () -> Unit,
  onOpenLanguagePicker: () -> Unit,
  onInspectAdSlot: (AdSlotSpec) -> Unit,
  modifier: Modifier = Modifier,
) {
  BoxWithConstraints(
    modifier = modifier.fillMaxSize().background(CanvasBlack).padding(horizontal = 16.dp, vertical = 12.dp)
  ) {
    val isExpandedLayout = maxWidth >= 680.dp

    if (isExpandedLayout) {
      Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
      ) {
        Column(
          modifier = Modifier.weight(1.1f).fillMaxHeight(),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          RadarHeaderBar(
            uiState = uiState,
            onOpenLanguagePicker = onOpenLanguagePicker,
          )
          CameraOrPermissionPane(
            uiState = uiState,
            localizedContextProvider = localizedContextProvider,
            onRequestCameraPermission = onRequestCameraPermission,
            onOpenAppSettings = onOpenAppSettings,
            onFrameAnalyzed = onFrameAnalyzed,
            modifier = Modifier.weight(1f),
          )
        }

        Column(
          modifier = Modifier.weight(0.9f).fillMaxHeight().verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          QuickTogglesRow(
            isScanning = uiState.isScanning,
            isTorchEnabled = uiState.isTorchEnabled,
            autoSpeakEnabled = uiState.preferences.autoSpeakEnabled,
            onToggleScanning = onToggleScanning,
            onToggleTorch = onToggleTorch,
            onToggleAutoSpeak = onToggleAutoSpeak,
          )
          LiveCueReadoutCard(uiState = uiState)
          RepeatAudioCueButton(
            isSpeaking = uiState.isSpeaking,
            onClick = onRepeatAudioCue,
          )
          Spacer(modifier = Modifier.weight(1f, fill = false))
          AdPlaceholderBanner(onInspectAdSlot = onInspectAdSlot)
        }
      }
    } else {
      Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        RadarHeaderBar(
          uiState = uiState,
          onOpenLanguagePicker = onOpenLanguagePicker,
        )

        QuickTogglesRow(
          isScanning = uiState.isScanning,
          isTorchEnabled = uiState.isTorchEnabled,
          autoSpeakEnabled = uiState.preferences.autoSpeakEnabled,
          onToggleScanning = onToggleScanning,
          onToggleTorch = onToggleTorch,
          onToggleAutoSpeak = onToggleAutoSpeak,
        )

        CameraOrPermissionPane(
          uiState = uiState,
          localizedContextProvider = localizedContextProvider,
          onRequestCameraPermission = onRequestCameraPermission,
          onOpenAppSettings = onOpenAppSettings,
          onFrameAnalyzed = onFrameAnalyzed,
          modifier = Modifier.weight(1f).heightIn(min = 180.dp),
        )

        LiveCueReadoutCard(uiState = uiState)

        RepeatAudioCueButton(
          isSpeaking = uiState.isSpeaking,
          onClick = onRepeatAudioCue,
        )

        AdPlaceholderBanner(onInspectAdSlot = onInspectAdSlot)
      }
    }
  }
}

@Composable
private fun RadarHeaderBar(
  uiState: RadarUiState,
  onOpenLanguagePicker: () -> Unit,
) {
  val tokens = LocalClarityTokens.current
  val statusText =
    when {
      !uiState.hasCameraPermission -> localizedString(R.string.status_no_camera)
      !uiState.isScanning -> localizedString(R.string.status_paused)
      uiState.highestSeverity == HazardSeverity.CRITICAL -> localizedString(R.string.status_hazard)
      uiState.highestSeverity == HazardSeverity.CAUTION -> localizedString(R.string.status_caution)
      else -> localizedString(R.string.status_scanning)
    }
  val statusColor =
    when {
      !uiState.hasCameraPermission || !uiState.isScanning -> tokens.primaryFocus
      else -> severityColor(uiState.highestSeverity)
    }
  val langBadge = resolveShortBadge(uiState.preferences.languageTag)
  val langButtonDesc = localizedString(R.string.change_language_button)

  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Text(
      text = localizedString(R.string.brand_title),
      style = MaterialTheme.typography.headlineSmall,
      color = PureWhite,
      fontWeight = FontWeight.ExtraBold,
      modifier = Modifier.semantics { heading() },
    )

    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        modifier =
          Modifier.heightIn(min = 48.dp)
            .testTag("header_language_button")
            .clip(RoundedCornerShape(4.dp))
            .background(CanvasBlack)
            .border(2.dp, tokens.secondaryAction, RoundedCornerShape(4.dp))
            .clickable(
              role = Role.Button,
              onClickLabel = langButtonDesc,
              onClick = onOpenLanguagePicker,
            )
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .semantics { contentDescription = "$langButtonDesc: $langBadge" },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.Translate,
          contentDescription = null,
          tint = tokens.secondaryAction,
          modifier = Modifier.size(18.dp),
        )
        Text(
          text = langBadge,
          style = MaterialTheme.typography.labelSmall,
          color = tokens.secondaryAction,
        )
      }

      ClarityStatusPill(
        text = statusText,
        accentColor = statusColor,
        modifier = Modifier.testTag("radar_status_pill"),
      )
    }
  }
}

@Composable
private fun QuickTogglesRow(
  isScanning: Boolean,
  isTorchEnabled: Boolean,
  autoSpeakEnabled: Boolean,
  onToggleScanning: () -> Unit,
  onToggleTorch: () -> Unit,
  onToggleAutoSpeak: () -> Unit,
) {
  val tokens = LocalClarityTokens.current
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    TactileToggleChip(
      label = if (isScanning) localizedString(R.string.toggle_pause) else localizedString(R.string.toggle_scan),
      icon = if (isScanning) Icons.Filled.Pause else Icons.Filled.PlayArrow,
      isActive = isScanning,
      activeColor = tokens.positiveSignal,
      inactiveColor = tokens.primaryFocus,
      contentDescriptionText =
        if (isScanning) localizedString(R.string.toggle_pause_desc)
        else localizedString(R.string.toggle_scan_desc),
      onClick = onToggleScanning,
      modifier = Modifier.weight(1f).testTag("toggle_scan_button"),
    )
    TactileToggleChip(
      label =
        if (isTorchEnabled) localizedString(R.string.toggle_light_on)
        else localizedString(R.string.toggle_light_off),
      icon = if (isTorchEnabled) Icons.Filled.FlashlightOn else Icons.Filled.FlashlightOff,
      isActive = isTorchEnabled,
      activeColor = tokens.primaryFocus,
      inactiveColor = tokens.secondaryAction,
      contentDescriptionText =
        if (isTorchEnabled) localizedString(R.string.toggle_light_on_desc)
        else localizedString(R.string.toggle_light_off_desc),
      onClick = onToggleTorch,
      modifier = Modifier.weight(1f).testTag("toggle_torch_button"),
    )
    TactileToggleChip(
      label =
        if (autoSpeakEnabled) localizedString(R.string.toggle_voice_on)
        else localizedString(R.string.toggle_voice_muted),
      icon =
        if (autoSpeakEnabled) Icons.AutoMirrored.Filled.VolumeUp
        else Icons.AutoMirrored.Filled.VolumeOff,
      isActive = autoSpeakEnabled,
      activeColor = tokens.secondaryAction,
      inactiveColor = tokens.criticalHazard,
      contentDescriptionText =
        if (autoSpeakEnabled) localizedString(R.string.toggle_voice_on_desc)
        else localizedString(R.string.toggle_voice_muted_desc),
      onClick = onToggleAutoSpeak,
      modifier = Modifier.weight(1f).testTag("toggle_voice_button"),
    )
  }
}

@Composable
private fun TactileToggleChip(
  label: String,
  icon: ImageVector,
  isActive: Boolean,
  activeColor: Color,
  inactiveColor: Color,
  contentDescriptionText: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val borderColor = if (isActive) activeColor else inactiveColor
  val bgColor = if (isActive) borderColor else CanvasBlack
  val fgColor = if (isActive) CanvasBlack else borderColor

  Row(
    modifier =
      modifier
        .heightIn(min = 56.dp)
        .clip(RoundedCornerShape(4.dp))
        .background(bgColor)
        .border(2.dp, borderColor, RoundedCornerShape(4.dp))
        .clickable(
          role = Role.Switch,
          onClickLabel = contentDescriptionText,
          onClick = onClick,
        )
        .padding(horizontal = 8.dp, vertical = 10.dp)
        .semantics { contentDescription = contentDescriptionText },
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = fgColor,
      modifier = Modifier.size(20.dp),
    )
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = fgColor,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
private fun CameraOrPermissionPane(
  uiState: RadarUiState,
  localizedContextProvider: () -> Context,
  onRequestCameraPermission: () -> Unit,
  onOpenAppSettings: () -> Unit,
  onFrameAnalyzed: (FrameAnalysisResult) -> Unit,
  modifier: Modifier = Modifier,
) {
  if (uiState.hasCameraPermission) {
    CameraObstacleViewport(
      isScanning = uiState.isScanning,
      isTorchEnabled = uiState.isTorchEnabled,
      obstacles = uiState.obstacles,
      zoneClearance = uiState.zoneClearance,
      highestSeverity = uiState.highestSeverity,
      localizedContextProvider = localizedContextProvider,
      onFrameAnalyzed = onFrameAnalyzed,
      modifier = modifier,
    )
  } else {
    val tokens = LocalClarityTokens.current
    Surface(
      modifier = modifier.fillMaxWidth().testTag("camera_permission_card"),
      shape = RoundedCornerShape(4.dp),
      color = SurfaceCharcoal,
      border = BorderStroke(3.dp, tokens.primaryFocus),
    ) {
      Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Icon(
          imageVector = Icons.Filled.CameraAlt,
          contentDescription = null,
          tint = tokens.primaryFocus,
          modifier = Modifier.size(48.dp),
        )
        Text(
          text = localizedString(R.string.permission_camera_title),
          style = MaterialTheme.typography.titleLarge,
          color = tokens.primaryFocus,
        )
        Text(
          text = localizedString(R.string.permission_camera_body),
          style = MaterialTheme.typography.bodyMedium,
          color = PureWhite,
        )
        ClarityPrimaryButton(
          text = localizedString(R.string.permission_camera_grant),
          onClick = onRequestCameraPermission,
          icon = Icons.Filled.CameraAlt,
          modifier = Modifier.testTag("grant_camera_permission_button"),
        )
        ClaritySecondaryButton(
          text = localizedString(R.string.permission_camera_settings),
          onClick = onOpenAppSettings,
          icon = Icons.Filled.Settings,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    }
  }
}

@Composable
private fun LiveCueReadoutCard(uiState: RadarUiState) {
  val accentColor = severityColor(uiState.highestSeverity)
  Surface(
    modifier =
      Modifier.fillMaxWidth()
        .testTag("live_cue_readout_card")
        .semantics {
          liveRegion =
            if (uiState.highestSeverity == HazardSeverity.CRITICAL) LiveRegionMode.Assertive
            else LiveRegionMode.Polite
        },
    shape = RoundedCornerShape(4.dp),
    color = SurfaceCharcoal,
    border = BorderStroke(3.dp, accentColor),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = localizedString(R.string.live_cue_header, uiState.highestSeverity.badgePrefix),
          style = MaterialTheme.typography.labelSmall,
          color = accentColor,
        )
        Text(
          text = uiState.lastCueTimestamp,
          style = MaterialTheme.typography.labelSmall,
          color = SoftWhiteText,
        )
      }
      Text(
        text = uiState.currentCueText,
        style = MaterialTheme.typography.titleLarge,
        color = PureWhite,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
private fun RepeatAudioCueButton(
  isSpeaking: Boolean,
  onClick: () -> Unit,
) {
  val tokens = LocalClarityTokens.current
  val buttonLabel =
    if (isSpeaking) localizedString(R.string.repeat_audio_cue_speaking)
    else localizedString(R.string.repeat_audio_cue)

  ClarityPrimaryButton(
    text = buttonLabel,
    onClick = onClick,
    icon = if (isSpeaking) Icons.AutoMirrored.Filled.VolumeUp else Icons.Filled.Replay,
    contentDescriptionText = localizedString(R.string.repeat_audio_cue_desc),
    minHeightDp = 72,
    containerColor = tokens.primaryFocus,
    contentColor = tokens.onPrimaryFocus,
    modifier = Modifier.testTag("repeat_audio_cue_button"),
  )
}
