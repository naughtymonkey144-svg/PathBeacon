package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.model.HighContrastPalette

@Immutable
data class ClarityAccentTokens(
  val primaryFocus: Color,
  val onPrimaryFocus: Color,
  val secondaryAction: Color,
  val onSecondaryAction: Color,
  val positiveSignal: Color,
  val criticalHazard: Color,
  val canvas: Color,
  val cardSurface: Color,
  val borderDefault: Color,
)

val LocalClarityTokens =
  staticCompositionLocalOf {
    ClarityAccentTokens(
      primaryFocus = SafetyYellow,
      onPrimaryFocus = OnSafetyYellow,
      secondaryAction = ElectricCyan,
      onSecondaryAction = OnElectricCyan,
      positiveSignal = EmeraldSignal,
      criticalHazard = CrimsonHazard,
      canvas = CanvasBlack,
      cardSurface = SurfaceCharcoal,
      borderDefault = PureWhite,
    )
  }

private val ClarityShapes =
  Shapes(
    extraSmall = RoundedCornerShape(2.dp),
    small = RoundedCornerShape(4.dp),
    medium = RoundedCornerShape(4.dp),
    large = RoundedCornerShape(8.dp),
    extraLarge = RoundedCornerShape(12.dp),
  )

@Composable
fun PathBeaconTheme(
  contrastPalette: HighContrastPalette = HighContrastPalette.SAFETY_YELLOW,
  content: @Composable () -> Unit,
) {
  val primaryFocus =
    when (contrastPalette) {
      HighContrastPalette.SAFETY_YELLOW -> SafetyYellow
      HighContrastPalette.ELECTRIC_CYAN -> ElectricCyan
      HighContrastPalette.STARK_WHITE -> PureWhite
    }

  val secondaryAction =
    when (contrastPalette) {
      HighContrastPalette.SAFETY_YELLOW -> ElectricCyan
      HighContrastPalette.ELECTRIC_CYAN -> SafetyYellow
      HighContrastPalette.STARK_WHITE -> ElectricCyan
    }

  val tokens =
    ClarityAccentTokens(
      primaryFocus = primaryFocus,
      onPrimaryFocus = CanvasBlack,
      secondaryAction = secondaryAction,
      onSecondaryAction = CanvasBlack,
      positiveSignal = EmeraldSignal,
      criticalHazard = CrimsonHazard,
      canvas = CanvasBlack,
      cardSurface = SurfaceCharcoal,
      borderDefault = PureWhite,
    )

  val colorScheme =
    darkColorScheme(
      primary = primaryFocus,
      onPrimary = CanvasBlack,
      primaryContainer = primaryFocus,
      onPrimaryContainer = CanvasBlack,
      secondary = secondaryAction,
      onSecondary = CanvasBlack,
      secondaryContainer = SurfaceContainer,
      onSecondaryContainer = secondaryAction,
      tertiary = EmeraldSignal,
      onTertiary = OnEmeraldSignal,
      tertiaryContainer = SurfaceContainer,
      onTertiaryContainer = EmeraldSignal,
      background = CanvasBlack,
      onBackground = PureWhite,
      surface = SurfaceCharcoal,
      onSurface = PureWhite,
      surfaceVariant = SurfaceContainer,
      onSurfaceVariant = SoftWhiteText,
      outline = PureWhite,
      outlineVariant = OutlineMuted,
      error = CrimsonHazard,
      onError = OnCrimson,
      errorContainer = CrimsonContainer,
      onErrorContainer = PureWhite,
    )

  CompositionLocalProvider(LocalClarityTokens provides tokens) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = ClarityTypography,
      shapes = ClarityShapes,
      content = content,
    )
  }
}
