package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

val AtkinsonHyperlegibleNextFamily =
  FontFamily(
    Font(R.font.atkinson_hyperlegible_next, FontWeight.Normal),
    Font(R.font.atkinson_hyperlegible_next, FontWeight.Medium),
    Font(R.font.atkinson_hyperlegible_next, FontWeight.Bold),
    Font(R.font.atkinson_hyperlegible_next, FontWeight.ExtraBold),
  )

// Clarity Spectrum Typography: minimum weight 400/500, bold/extrabold for controls, 140-155% line height
val ClarityTypography =
  Typography(
    displaySmall =
      TextStyle(
        fontFamily = AtkinsonHyperlegibleNextFamily,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 32.sp,
        lineHeight = 42.sp,
        letterSpacing = (-0.01).sp,
      ),
    headlineMedium =
      TextStyle(
        fontFamily = AtkinsonHyperlegibleNextFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp,
        lineHeight = 36.sp,
        letterSpacing = 0.sp,
      ),
    headlineSmall =
      TextStyle(
        fontFamily = AtkinsonHyperlegibleNextFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 32.sp,
        letterSpacing = 0.01.sp,
      ),
    titleLarge =
      TextStyle(
        fontFamily = AtkinsonHyperlegibleNextFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 28.sp,
        letterSpacing = 0.02.sp,
      ),
    titleMedium =
      TextStyle(
        fontFamily = AtkinsonHyperlegibleNextFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        lineHeight = 26.sp,
        letterSpacing = 0.03.sp,
      ),
    bodyLarge =
      TextStyle(
        fontFamily = AtkinsonHyperlegibleNextFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 18.sp,
        lineHeight = 27.sp,
        letterSpacing = 0.02.sp,
      ),
    bodyMedium =
      TextStyle(
        fontFamily = AtkinsonHyperlegibleNextFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.02.sp,
      ),
    labelLarge =
      TextStyle(
        fontFamily = AtkinsonHyperlegibleNextFamily,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 18.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.06.sp,
      ),
    labelMedium =
      TextStyle(
        fontFamily = AtkinsonHyperlegibleNextFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 15.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.06.sp,
      ),
    labelSmall =
      TextStyle(
        fontFamily = AtkinsonHyperlegibleNextFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        letterSpacing = 0.08.sp,
      ),
  )
