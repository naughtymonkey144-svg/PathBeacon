package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.localization.localizedString
import com.example.localization.resolveLanguageOption
import com.example.model.AccessibilityPreferences
import com.example.model.AdSlotSpec
import com.example.model.HighContrastPalette
import com.example.ui.components.AdPlaceholderBanner
import com.example.ui.components.ClarityPrimaryButton
import com.example.ui.components.ClaritySecondaryButton
import com.example.ui.components.ClarityStatusPill
import com.example.ui.theme.CanvasBlack
import com.example.ui.theme.LocalClarityTokens
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftWhiteText
import com.example.ui.theme.SurfaceCharcoal

@Composable
fun ControlsScreen(
  preferences: AccessibilityPreferences,
  isTtsLanguageAvailable: Boolean,
  onOpenLanguagePicker: () -> Unit,
  onToggleAutoSpeak: () -> Unit,
  onToggleHaptics: (Boolean) -> Unit,
  onSelectSpeechRate: (Float) -> Unit,
  onSelectIntervalSeconds: (Int) -> Unit,
  onSelectPalette: (HighContrastPalette) -> Unit,
  onTestVoiceAndHaptic: () -> Unit,
  onInspectAdSlot: (AdSlotSpec) -> Unit,
  modifier: Modifier = Modifier,
) {
  val tokens = LocalClarityTokens.current
  val currentLangOption = resolveLanguageOption(preferences.languageTag)
  val currentLangLabel =
    if (preferences.languageTag.isBlank()) localizedString(R.string.language_system_default)
    else currentLangOption.nativeName

  Column(
    modifier =
      modifier
        .fillMaxSize()
        .background(CanvasBlack)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    Text(
      text = localizedString(R.string.controls_title),
      style = MaterialTheme.typography.headlineSmall,
      color = PureWhite,
      modifier = Modifier.semantics { heading() },
    )

    // Language Selection Card
    Surface(
      modifier = Modifier.fillMaxWidth().testTag("language_settings_card"),
      shape = RoundedCornerShape(4.dp),
      color = SurfaceCharcoal,
      border = BorderStroke(3.dp, tokens.primaryFocus),
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = localizedString(R.string.setting_language_title),
            style = MaterialTheme.typography.titleMedium,
            color = PureWhite,
            modifier = Modifier.weight(1f),
          )
          ClarityStatusPill(
            text = currentLangOption.shortCode,
            accentColor = tokens.primaryFocus,
          )
        }
        Text(
          text = localizedString(R.string.setting_language_subtitle),
          style = MaterialTheme.typography.bodyMedium,
          color = SoftWhiteText,
        )
        Text(
          text = currentLangLabel,
          style = MaterialTheme.typography.titleLarge,
          color = tokens.primaryFocus,
        )
        if (!isTtsLanguageAvailable) {
          Text(
            text = localizedString(R.string.language_tts_unavailable, currentLangLabel),
            style = MaterialTheme.typography.bodyMedium,
            color = tokens.criticalHazard,
          )
        }
        ClaritySecondaryButton(
          text = localizedString(R.string.change_language_button),
          onClick = onOpenLanguagePicker,
          icon = Icons.Filled.Translate,
          accentColor = tokens.primaryFocus,
          modifier = Modifier.fillMaxWidth().testTag("open_language_picker_button"),
        )
      }
    }

    SettingSwitchCard(
      title = localizedString(R.string.setting_auto_speak_title),
      subtitle = localizedString(R.string.setting_auto_speak_subtitle),
      checked = preferences.autoSpeakEnabled,
      onCheckedChange = { onToggleAutoSpeak() },
      testTagName = "switch_auto_speak",
    )

    SettingSwitchCard(
      title = localizedString(R.string.setting_haptic_title),
      subtitle = localizedString(R.string.setting_haptic_subtitle),
      checked = preferences.hapticAlertsEnabled,
      onCheckedChange = onToggleHaptics,
      testTagName = "switch_haptic_alerts",
    )

    Surface(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(4.dp),
      color = SurfaceCharcoal,
      border = BorderStroke(2.dp, PureWhite),
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text(
          text = localizedString(R.string.setting_speech_speed_title),
          style = MaterialTheme.typography.titleMedium,
          color = PureWhite,
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          listOf(0.75f to "0.75x", 1.0f to "1.0x", 1.25f to "1.25x", 1.5f to "1.5x").forEach {
            (rate, label) ->
            val selected = kotlin.math.abs(preferences.speechRate - rate) < 0.05f
            OptionPillTile(
              label = label,
              selected = selected,
              onClick = { onSelectSpeechRate(rate) },
              modifier = Modifier.weight(1f),
            )
          }
        }
      }
    }

    Surface(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(4.dp),
      color = SurfaceCharcoal,
      border = BorderStroke(2.dp, PureWhite),
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text(
          text = localizedString(R.string.setting_cadence_title),
          style = MaterialTheme.typography.titleMedium,
          color = PureWhite,
        )
        Text(
          text = localizedString(R.string.setting_cadence_subtitle),
          style = MaterialTheme.typography.bodyMedium,
          color = SoftWhiteText,
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          listOf(2, 4, 8).forEach { sec ->
            OptionPillTile(
              label = localizedString(R.string.cadence_seconds, sec),
              selected = preferences.repeatIntervalSeconds == sec,
              onClick = { onSelectIntervalSeconds(sec) },
              modifier = Modifier.weight(1f),
            )
          }
        }
      }
    }

    Surface(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(4.dp),
      color = SurfaceCharcoal,
      border = BorderStroke(2.dp, PureWhite),
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text(
          text = localizedString(R.string.setting_palette_title),
          style = MaterialTheme.typography.titleMedium,
          color = PureWhite,
        )
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          HighContrastPalette.entries.forEach { palette ->
            val selected = preferences.highContrastPalette == palette
            val name = localizedString(palette.displayNameRes)
            OptionPillTile(
              label = if (selected) "[●] $name" else name,
              selected = selected,
              onClick = { onSelectPalette(palette) },
              modifier = Modifier.fillMaxWidth().testTag("palette_${palette.name.lowercase()}"),
            )
          }
        }
      }
    }

    ClarityPrimaryButton(
      text = localizedString(R.string.test_voice_haptic),
      onClick = onTestVoiceAndHaptic,
      icon = Icons.AutoMirrored.Filled.VolumeUp,
      containerColor = tokens.secondaryAction,
      contentColor = tokens.onSecondaryAction,
      modifier = Modifier.testTag("test_voice_haptic_button"),
    )

    Surface(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(4.dp),
      color = SurfaceCharcoal,
      border = BorderStroke(2.dp, tokens.secondaryAction),
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          ClarityStatusPill(
            text = localizedString(R.string.ad_badge_label),
            accentColor = tokens.secondaryAction,
          )
          Text(
            text = localizedString(R.string.ad_standards_title),
            style = MaterialTheme.typography.titleMedium,
            color = PureWhite,
          )
        }
        Text(
          text = localizedString(R.string.ad_standards_body),
          style = MaterialTheme.typography.bodyMedium,
          color = SoftWhiteText,
        )
        AdPlaceholderBanner(onInspectAdSlot = onInspectAdSlot)
      }
    }
  }
}

@Composable
private fun SettingSwitchCard(
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  testTagName: String,
) {
  val tokens = LocalClarityTokens.current
  val borderColor = if (checked) tokens.positiveSignal else PureWhite
  val stateWord =
    if (checked) localizedString(R.string.state_enabled)
    else localizedString(R.string.state_disabled)

  Surface(
    modifier =
      Modifier.fillMaxWidth()
        .heightIn(min = 72.dp)
        .testTag(testTagName)
        .clickable(
          role = Role.Switch,
          onClickLabel = title,
          onClick = { onCheckedChange(!checked) },
        )
        .semantics { contentDescription = "$title, $stateWord" },
    shape = RoundedCornerShape(4.dp),
    color = SurfaceCharcoal,
    border = BorderStroke(2.dp, borderColor),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(text = title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
        Text(text = subtitle, style = MaterialTheme.typography.bodyMedium, color = SoftWhiteText)
      }
      Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors =
          SwitchDefaults.colors(
            checkedThumbColor = CanvasBlack,
            checkedTrackColor = tokens.positiveSignal,
            uncheckedThumbColor = PureWhite,
            uncheckedTrackColor = CanvasBlack,
            uncheckedBorderColor = PureWhite,
          ),
      )
    }
  }
}

@Composable
private fun OptionPillTile(
  label: String,
  selected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val tokens = LocalClarityTokens.current
  val bgColor = if (selected) tokens.primaryFocus else CanvasBlack
  val fgColor = if (selected) tokens.onPrimaryFocus else PureWhite
  val borderColor = if (selected) tokens.primaryFocus else PureWhite

  Row(
    modifier =
      modifier
        .heightIn(min = 56.dp)
        .clip(RoundedCornerShape(4.dp))
        .background(bgColor)
        .border(2.dp, borderColor, RoundedCornerShape(4.dp))
        .clickable(role = Role.RadioButton, onClick = onClick)
        .padding(horizontal = 12.dp, vertical = 12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.Center,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium,
      fontWeight = FontWeight.Bold,
      color = fgColor,
    )
  }
}
