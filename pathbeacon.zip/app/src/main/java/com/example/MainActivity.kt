package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.localization.LocalLocalizedContext
import com.example.localization.layoutDirectionForTag
import com.example.localization.localizedString
import com.example.localization.rememberLocalizedContext
import com.example.ui.RadarViewModel
import com.example.ui.components.AdSlotDetailDialog
import com.example.ui.components.ClarityLanguageDialog
import com.example.ui.screens.ControlsScreen
import com.example.ui.screens.CueLogScreen
import com.example.ui.screens.LiveRadarScreen
import com.example.ui.theme.CanvasBlack
import com.example.ui.theme.LocalClarityTokens
import com.example.ui.theme.PathBeaconTheme
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SurfaceCharcoal

private const val ROUTE_RADAR = "live_radar"
private const val ROUTE_CUE_LOG = "cue_log"
private const val ROUTE_CONTROLS = "controls"

private data class NavDestination(
  val route: String,
  val labelRes: Int,
  val icon: ImageVector,
  val testTag: String,
)

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(android.graphics.Color.BLACK),
      navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.BLACK),
    )
    setContent { PathBeaconApp() }
  }
}

@Composable
fun PathBeaconApp(viewModel: RadarViewModel = viewModel()) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current
  val localizedContext = rememberLocalizedContext(uiState.preferences.languageTag)
  val layoutDirection = layoutDirectionForTag(uiState.preferences.languageTag)

  val cameraPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      viewModel.onCameraPermissionChanged(granted)
    }

  LaunchedEffect(Unit) {
    val granted =
      ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
        PackageManager.PERMISSION_GRANTED
    viewModel.onCameraPermissionChanged(granted)
    if (!granted) {
      cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }
  }

  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) {
        val granted =
          ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        viewModel.onCameraPermissionChanged(granted)
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
  }

  val navDestinations =
    listOf(
      NavDestination(ROUTE_RADAR, R.string.nav_radar, Icons.Filled.Radar, "nav_radar"),
      NavDestination(ROUTE_CUE_LOG, R.string.nav_cue_log, Icons.Filled.History, "nav_cue_log"),
      NavDestination(ROUTE_CONTROLS, R.string.nav_settings, Icons.Filled.Tune, "nav_controls"),
    )

  val navController = rememberNavController()
  val backStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = backStackEntry?.destination?.route ?: ROUTE_RADAR

  val navigateToTab: (String) -> Unit = { route ->
    navController.navigate(route) {
      popUpTo(navController.graph.findStartDestination().id) { saveState = true }
      launchSingleTop = true
      restoreState = true
    }
  }

  CompositionLocalProvider(
    LocalLocalizedContext provides localizedContext,
    LocalLayoutDirection provides layoutDirection,
  ) {
    PathBeaconTheme(contrastPalette = uiState.preferences.highContrastPalette) {
      val tokens = LocalClarityTokens.current

      BoxWithConstraints(modifier = Modifier.fillMaxSize().background(CanvasBlack)) {
        val useNavigationRail = maxWidth >= 840.dp

        Scaffold(
          containerColor = CanvasBlack,
          contentWindowInsets = WindowInsets.safeDrawing,
          bottomBar = {
            if (!useNavigationRail) {
              Column(modifier = Modifier.fillMaxWidth().background(SurfaceCharcoal)) {
                HorizontalDivider(thickness = 2.dp, color = PureWhite)
                NavigationBar(
                  containerColor = SurfaceCharcoal,
                  contentColor = PureWhite,
                  windowInsets = WindowInsets.navigationBars,
                ) {
                  navDestinations.forEach { dest ->
                    val selected = currentRoute == dest.route
                    val labelText = localizedString(dest.labelRes)
                    NavigationBarItem(
                      selected = selected,
                      onClick = { navigateToTab(dest.route) },
                      modifier = Modifier.testTag(dest.testTag),
                      icon = {
                        Icon(
                          imageVector = dest.icon,
                          contentDescription = labelText,
                        )
                      },
                      label = {
                        Text(
                          text = labelText.uppercase(),
                          style = MaterialTheme.typography.labelSmall,
                        )
                      },
                      colors =
                        NavigationBarItemDefaults.colors(
                          selectedIconColor = tokens.onPrimaryFocus,
                          selectedTextColor = tokens.primaryFocus,
                          indicatorColor = tokens.primaryFocus,
                          unselectedIconColor = PureWhite,
                          unselectedTextColor = PureWhite,
                        ),
                    )
                  }
                }
              }
            }
          },
        ) { innerPadding ->
          Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            if (useNavigationRail) {
              NavigationRail(
                containerColor = SurfaceCharcoal,
                contentColor = PureWhite,
                modifier = Modifier.fillMaxHeight().width(96.dp),
              ) {
                navDestinations.forEach { dest ->
                  val selected = currentRoute == dest.route
                  val labelText = localizedString(dest.labelRes)
                  NavigationRailItem(
                    selected = selected,
                    onClick = { navigateToTab(dest.route) },
                    modifier = Modifier.testTag(dest.testTag),
                    icon = {
                      Icon(
                        imageVector = dest.icon,
                        contentDescription = labelText,
                      )
                    },
                    label = {
                      Text(
                        text = labelText.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                      )
                    },
                    colors =
                      NavigationRailItemDefaults.colors(
                        selectedIconColor = tokens.onPrimaryFocus,
                        selectedTextColor = tokens.primaryFocus,
                        indicatorColor = tokens.primaryFocus,
                        unselectedIconColor = PureWhite,
                        unselectedTextColor = PureWhite,
                      ),
                  )
                }
              }
              VerticalDivider(thickness = 2.dp, color = PureWhite)
            }

            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
              NavHost(
                navController = navController,
                startDestination = ROUTE_RADAR,
                modifier = Modifier.fillMaxSize(),
              ) {
                composable(ROUTE_RADAR) {
                  LiveRadarScreen(
                    uiState = uiState,
                    localizedContextProvider = viewModel::currentLocalizedContext,
                    onRequestCameraPermission = {
                      cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    },
                    onOpenAppSettings = {
                      val intent =
                        Intent(
                          Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                          Uri.fromParts("package", context.packageName, null),
                        )
                      context.startActivity(intent)
                    },
                    onFrameAnalyzed = viewModel::onFrameAnalyzed,
                    onToggleScanning = viewModel::toggleScanning,
                    onToggleTorch = viewModel::toggleTorch,
                    onToggleAutoSpeak = viewModel::toggleAutoSpeak,
                    onRepeatAudioCue = viewModel::onRepeatAudioCueClicked,
                    onOpenLanguagePicker = viewModel::openLanguageDialog,
                    onInspectAdSlot = viewModel::openAdSlotDetail,
                  )
                }

                composable(ROUTE_CUE_LOG) {
                  CueLogScreen(
                    cueHistory = uiState.cueHistory,
                    onReplayCue = viewModel::replayHistoricalCue,
                    onClearHistory = viewModel::clearCueHistory,
                    onInspectAdSlot = viewModel::openAdSlotDetail,
                  )
                }

                composable(ROUTE_CONTROLS) {
                  ControlsScreen(
                    preferences = uiState.preferences,
                    isTtsLanguageAvailable = uiState.isTtsLanguageAvailable,
                    onOpenLanguagePicker = viewModel::openLanguageDialog,
                    onToggleAutoSpeak = viewModel::toggleAutoSpeak,
                    onToggleHaptics = viewModel::setHapticAlertsEnabled,
                    onSelectSpeechRate = viewModel::setSpeechRate,
                    onSelectIntervalSeconds = viewModel::setRepeatIntervalSeconds,
                    onSelectPalette = viewModel::setHighContrastPalette,
                    onTestVoiceAndHaptic = viewModel::testVoiceAndHaptic,
                    onInspectAdSlot = viewModel::openAdSlotDetail,
                  )
                }
              }
            }
          }
        }

        uiState.activeAdDetail?.let { spec ->
          AdSlotDetailDialog(
            spec = spec,
            onDismiss = viewModel::dismissAdSlotDetail,
          )
        }

        if (uiState.isLanguageDialogOpen) {
          ClarityLanguageDialog(
            selectedLanguageTag = uiState.preferences.languageTag,
            onSelectLanguage = viewModel::selectLanguage,
            onDismiss = viewModel::dismissLanguageDialog,
          )
        }
      }
    }
  }
}
