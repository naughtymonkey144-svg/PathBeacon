package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AccessibilityPreferences
import com.example.model.HighContrastPalette
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.pathBeaconDataStore: DataStore<Preferences> by
  preferencesDataStore(name = "pathbeacon_preferences")

class PreferencesRepository(private val context: Context) {

  private object Keys {
    val AUTO_SPEAK = booleanPreferencesKey("auto_speak_enabled")
    val SPEECH_RATE = floatPreferencesKey("speech_rate")
    val HAPTIC_ALERTS = booleanPreferencesKey("haptic_alerts_enabled")
    val REPEAT_INTERVAL_SEC = intPreferencesKey("repeat_interval_seconds")
    val CONTRAST_PALETTE = stringPreferencesKey("contrast_palette")
    val LANGUAGE_TAG = stringPreferencesKey("language_tag")
  }

  val preferencesFlow: Flow<AccessibilityPreferences> =
    context.pathBeaconDataStore.data.map { prefs ->
      val paletteName = prefs[Keys.CONTRAST_PALETTE]
      val palette =
        HighContrastPalette.entries.firstOrNull { it.name == paletteName }
          ?: HighContrastPalette.SAFETY_YELLOW

      AccessibilityPreferences(
        autoSpeakEnabled = prefs[Keys.AUTO_SPEAK] ?: true,
        speechRate = (prefs[Keys.SPEECH_RATE] ?: 1.0f).coerceIn(0.75f, 1.75f),
        hapticAlertsEnabled = prefs[Keys.HAPTIC_ALERTS] ?: true,
        repeatIntervalSeconds = (prefs[Keys.REPEAT_INTERVAL_SEC] ?: 4).coerceIn(2, 12),
        highContrastPalette = palette,
        languageTag = prefs[Keys.LANGUAGE_TAG] ?: "",
      )
    }

  suspend fun setAutoSpeakEnabled(enabled: Boolean) {
    context.pathBeaconDataStore.edit { it[Keys.AUTO_SPEAK] = enabled }
  }

  suspend fun setSpeechRate(rate: Float) {
    context.pathBeaconDataStore.edit { it[Keys.SPEECH_RATE] = rate.coerceIn(0.75f, 1.75f) }
  }

  suspend fun setHapticAlertsEnabled(enabled: Boolean) {
    context.pathBeaconDataStore.edit { it[Keys.HAPTIC_ALERTS] = enabled }
  }

  suspend fun setRepeatIntervalSeconds(seconds: Int) {
    context.pathBeaconDataStore.edit { it[Keys.REPEAT_INTERVAL_SEC] = seconds.coerceIn(2, 12) }
  }

  suspend fun setHighContrastPalette(palette: HighContrastPalette) {
    context.pathBeaconDataStore.edit { it[Keys.CONTRAST_PALETTE] = palette.name }
  }

  suspend fun setLanguageTag(languageTag: String) {
    context.pathBeaconDataStore.edit { it[Keys.LANGUAGE_TAG] = languageTag }
  }
}
