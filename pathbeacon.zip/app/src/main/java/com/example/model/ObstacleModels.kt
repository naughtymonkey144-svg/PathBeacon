package com.example.model

import androidx.annotation.StringRes
import androidx.compose.runtime.Immutable
import com.example.R

enum class HazardSeverity(
  val badgePrefix: String,
  @StringRes val spokenPrefixRes: Int,
) {
  CLEAR("[●]", R.string.severity_spoken_clear),
  INFO("[i]", R.string.severity_spoken_info),
  CAUTION("[!]", R.string.severity_spoken_caution),
  CRITICAL("[X]", R.string.severity_spoken_critical),
}

enum class CorridorZone(
  @StringRes val labelRes: Int,
  @StringRes val clockCueRes: Int,
) {
  LEFT(R.string.zone_label_left, R.string.zone_clock_left),
  CENTER(R.string.zone_label_center, R.string.zone_clock_center),
  RIGHT(R.string.zone_label_right, R.string.zone_clock_right),
}

enum class ProximityBand(
  val label: String,
  @StringRes val spokenDistanceRes: Int,
) {
  IMMEDIATE("IMMEDIATE", R.string.proximity_immediate),
  NEAR("NEAR", R.string.proximity_near),
  FAR("FAR", R.string.proximity_far),
}

@Immutable
data class DetectedObstacle(
  val id: Int,
  val label: String,
  val leftNorm: Float,
  val topNorm: Float,
  val rightNorm: Float,
  val bottomNorm: Float,
  val zone: CorridorZone,
  val proximity: ProximityBand,
  val severity: HazardSeverity,
  val confidence: Float,
)

@Immutable
data class ZoneClearance(
  val leftObstacleLoad: Float = 0f,
  val centerObstacleLoad: Float = 0f,
  val rightObstacleLoad: Float = 0f,
)

@Immutable
data class AudioCueEntry(
  val id: Long,
  val timestampFormatted: String,
  val spokenText: String,
  val severity: HazardSeverity,
  val zoneLabel: String,
)

enum class HighContrastPalette(@StringRes val displayNameRes: Int) {
  SAFETY_YELLOW(R.string.palette_safety_yellow),
  ELECTRIC_CYAN(R.string.palette_electric_cyan),
  STARK_WHITE(R.string.palette_stark_white),
}

@Immutable
data class AccessibilityPreferences(
  val autoSpeakEnabled: Boolean = true,
  val speechRate: Float = 1.0f,
  val hapticAlertsEnabled: Boolean = true,
  val repeatIntervalSeconds: Int = 4,
  val highContrastPalette: HighContrastPalette = HighContrastPalette.SAFETY_YELLOW,
  val languageTag: String = "",
)

@Immutable
data class AdSlotSpec(
  val id: String,
  val title: String,
  val formatLabel: String,
  val dimensionsLabel: String,
  val placementNotes: String,
)
