package com.example.vision

import android.content.Context
import android.graphics.Rect
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.example.R
import com.example.model.CorridorZone
import com.example.model.DetectedObstacle
import com.example.model.HazardSeverity
import com.example.model.ProximityBand
import com.example.model.ZoneClearance
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.DetectedObject
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import java.nio.ByteBuffer
import java.util.Locale
import kotlin.math.abs

data class FrameAnalysisResult(
  val obstacles: List<DetectedObstacle>,
  val zoneClearance: ZoneClearance,
  val highestSeverity: HazardSeverity,
  val primaryCueText: String,
  val primaryZoneLabel: String,
)

class ObstacleFrameAnalyzer(
  private val contextProvider: () -> Context,
  private val onAnalysisResult: (FrameAnalysisResult) -> Unit,
) : ImageAnalysis.Analyzer {

  private val detector =
    ObjectDetection.getClient(
      ObjectDetectorOptions.Builder()
        .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
        .enableMultipleObjects()
        .enableClassification()
        .build()
    )

  @Volatile private var lastProcessedTimestampMs = 0L
  @Volatile private var isPaused = false

  fun setPaused(paused: Boolean) {
    isPaused = paused
  }

  fun close() {
    detector.close()
  }

  @OptIn(ExperimentalGetImage::class)
  override fun analyze(imageProxy: ImageProxy) {
    val now = System.currentTimeMillis()
    if (isPaused || now - lastProcessedTimestampMs < ANALYSIS_INTERVAL_MS) {
      imageProxy.close()
      return
    }
    val mediaImage = imageProxy.image
    if (mediaImage == null) {
      imageProxy.close()
      return
    }

    lastProcessedTimestampMs = now
    val rotation = imageProxy.imageInfo.rotationDegrees
    val uprightWidth =
      if (rotation == 90 || rotation == 270) imageProxy.height else imageProxy.width
    val uprightHeight =
      if (rotation == 90 || rotation == 270) imageProxy.width else imageProxy.height

    val yPlane = imageProxy.planes.firstOrNull()
    val corridorLoad =
      if (yPlane != null) {
        computeCorridorObstacleLoad(
          buffer = yPlane.buffer,
          width = imageProxy.width,
          height = imageProxy.height,
          rowStride = yPlane.rowStride,
          pixelStride = yPlane.pixelStride,
          rotationDegrees = rotation,
        )
      } else {
        ZoneClearance()
      }

    val inputImage = InputImage.fromMediaImage(mediaImage, rotation)
    detector
      .process(inputImage)
      .addOnSuccessListener { detectedObjects ->
        val result =
          buildAnalysisResult(
            ctx = contextProvider(),
            detectedObjects = detectedObjects,
            frameWidth = uprightWidth.coerceAtLeast(1),
            frameHeight = uprightHeight.coerceAtLeast(1),
            corridorLoad = corridorLoad,
          )
        onAnalysisResult(result)
      }
      .addOnFailureListener {
        val ctx = contextProvider()
        onAnalysisResult(
          FrameAnalysisResult(
            obstacles = emptyList(),
            zoneClearance = corridorLoad,
            highestSeverity = HazardSeverity.CLEAR,
            primaryCueText = ctx.getString(R.string.cue_scanning_steady),
            primaryZoneLabel = ctx.getString(R.string.zone_label_scan),
          )
        )
      }
      .addOnCompleteListener { imageProxy.close() }
  }

  private fun buildAnalysisResult(
    ctx: Context,
    detectedObjects: List<DetectedObject>,
    frameWidth: Int,
    frameHeight: Int,
    corridorLoad: ZoneClearance,
  ): FrameAnalysisResult {
    val mappedObstacles =
      detectedObjects
        .mapIndexedNotNull { index, obj ->
          mapDetectedObject(ctx, index, obj, frameWidth, frameHeight)
        }
        .sortedByDescending {
          severityRank(it.severity) * 10f +
            (it.rightNorm - it.leftNorm) * (it.bottomNorm - it.topNorm)
        }
        .take(5)

    var leftLoad = corridorLoad.leftObstacleLoad
    var centerLoad = corridorLoad.centerObstacleLoad
    var rightLoad = corridorLoad.rightObstacleLoad

    for (obstacle in mappedObstacles) {
      val area = (obstacle.rightNorm - obstacle.leftNorm) * (obstacle.bottomNorm - obstacle.topNorm)
      val boost = (area * 2.2f).coerceIn(0.15f, 1.0f)
      when (obstacle.zone) {
        CorridorZone.LEFT -> leftLoad = maxOf(leftLoad, boost)
        CorridorZone.CENTER -> centerLoad = maxOf(centerLoad, boost)
        CorridorZone.RIGHT -> rightLoad = maxOf(rightLoad, boost)
      }
    }

    val updatedClearance =
      ZoneClearance(
        leftObstacleLoad = leftLoad.coerceIn(0f, 1f),
        centerObstacleLoad = centerLoad.coerceIn(0f, 1f),
        rightObstacleLoad = rightLoad.coerceIn(0f, 1f),
      )

    val topObstacle = mappedObstacles.firstOrNull()
    if (topObstacle != null) {
      val severityText = ctx.getString(topObstacle.severity.spokenPrefixRes)
      val clockText = ctx.getString(topObstacle.zone.clockCueRes)
      val distanceText = ctx.getString(topObstacle.proximity.spokenDistanceRes)
      val cue =
        ctx.getString(
          R.string.cue_obstacle_template,
          severityText,
          topObstacle.label,
          clockText,
          distanceText,
        )
      return FrameAnalysisResult(
        obstacles = mappedObstacles,
        zoneClearance = updatedClearance,
        highestSeverity = topObstacle.severity,
        primaryCueText = cue,
        primaryZoneLabel = ctx.getString(topObstacle.zone.labelRes),
      )
    }

    val maxLoad =
      maxOf(
        updatedClearance.leftObstacleLoad,
        updatedClearance.centerObstacleLoad,
        updatedClearance.rightObstacleLoad,
      )
    return if (updatedClearance.centerObstacleLoad >= 0.72f) {
      FrameAnalysisResult(
        obstacles = emptyList(),
        zoneClearance = updatedClearance,
        highestSeverity = HazardSeverity.CAUTION,
        primaryCueText = ctx.getString(R.string.cue_surface_ahead),
        primaryZoneLabel = ctx.getString(CorridorZone.CENTER.labelRes),
      )
    } else if (maxLoad >= 0.78f) {
      val sideZone =
        if (updatedClearance.leftObstacleLoad > updatedClearance.rightObstacleLoad) {
          CorridorZone.LEFT
        } else {
          CorridorZone.RIGHT
        }
      FrameAnalysisResult(
        obstacles = emptyList(),
        zoneClearance = updatedClearance,
        highestSeverity = HazardSeverity.INFO,
        primaryCueText =
          ctx.getString(R.string.cue_side_structure, ctx.getString(sideZone.clockCueRes)),
        primaryZoneLabel = ctx.getString(sideZone.labelRes),
      )
    } else {
      FrameAnalysisResult(
        obstacles = emptyList(),
        zoneClearance = updatedClearance,
        highestSeverity = HazardSeverity.CLEAR,
        primaryCueText = ctx.getString(R.string.cue_path_clear),
        primaryZoneLabel = ctx.getString(R.string.zone_label_clear),
      )
    }
  }

  private fun mapDetectedObject(
    ctx: Context,
    index: Int,
    obj: DetectedObject,
    frameWidth: Int,
    frameHeight: Int,
  ): DetectedObstacle? {
    val box: Rect = obj.boundingBox
    val left = (box.left.toFloat() / frameWidth).coerceIn(0f, 1f)
    val top = (box.top.toFloat() / frameHeight).coerceIn(0f, 1f)
    val right = (box.right.toFloat() / frameWidth).coerceIn(0f, 1f)
    val bottom = (box.bottom.toFloat() / frameHeight).coerceIn(0f, 1f)

    val boxWidth = (right - left).coerceAtLeast(0f)
    val boxHeight = (bottom - top).coerceAtLeast(0f)
    val areaFraction = boxWidth * boxHeight
    if (areaFraction < 0.015f) return null

    val centerX = (left + right) / 2f
    val zone =
      when {
        centerX < 0.34f -> CorridorZone.LEFT
        centerX > 0.66f -> CorridorZone.RIGHT
        else -> CorridorZone.CENTER
      }

    val proximity =
      when {
        areaFraction >= 0.24f || (bottom >= 0.88f && areaFraction >= 0.12f) ->
          ProximityBand.IMMEDIATE
        areaFraction >= 0.08f -> ProximityBand.NEAR
        else -> ProximityBand.FAR
      }

    val severity =
      when {
        proximity == ProximityBand.IMMEDIATE -> HazardSeverity.CRITICAL
        proximity == ProximityBand.NEAR && zone == CorridorZone.CENTER -> HazardSeverity.CRITICAL
        proximity == ProximityBand.NEAR -> HazardSeverity.CAUTION
        else -> HazardSeverity.INFO
      }

    val bestLabel = obj.labels.maxByOrNull { it.confidence }
    val displayLabel = localizeMlKitLabel(ctx, bestLabel?.text)
    val confidence = bestLabel?.confidence ?: 0.65f

    return DetectedObstacle(
      id = obj.trackingId ?: index,
      label = displayLabel,
      leftNorm = left,
      topNorm = top,
      rightNorm = right,
      bottomNorm = bottom,
      zone = zone,
      proximity = proximity,
      severity = severity,
      confidence = confidence,
    )
  }

  private fun localizeMlKitLabel(ctx: Context, rawLabel: String?): String {
    return when (rawLabel?.trim()?.lowercase(Locale.US)) {
      "home good" -> ctx.getString(R.string.obstacle_label_home_good)
      "fashion good" -> ctx.getString(R.string.obstacle_label_fashion_good)
      "food" -> ctx.getString(R.string.obstacle_label_food)
      "place" -> ctx.getString(R.string.obstacle_label_place)
      "plant" -> ctx.getString(R.string.obstacle_label_plant)
      null, "" -> ctx.getString(R.string.obstacle_label_generic)
      else -> rawLabel
    }
  }

  private fun computeCorridorObstacleLoad(
    buffer: ByteBuffer,
    width: Int,
    height: Int,
    rowStride: Int,
    pixelStride: Int,
    rotationDegrees: Int,
  ): ZoneClearance {
    val step = 12
    val sums = FloatArray(3)
    val counts = IntArray(3)
    val limit = buffer.limit()

    var y = step
    while (y < height - step) {
      var x = step
      while (x < width - step) {
        val idx = y * rowStride + x * pixelStride
        val idxRight = y * rowStride + (x + step) * pixelStride
        val idxDown = (y + step) * rowStride + x * pixelStride
        if (idx >= 0 && idxRight < limit && idxDown < limit) {
          val lum = buffer.get(idx).toInt() and 0xFF
          val lumR = buffer.get(idxRight).toInt() and 0xFF
          val lumD = buffer.get(idxDown).toInt() and 0xFF
          val edge = (abs(lum - lumR) + abs(lum - lumD)) / 510f

          val normX =
            when (rotationDegrees) {
              90 -> 1f - (y.toFloat() / height)
              180 -> 1f - (x.toFloat() / width)
              270 -> y.toFloat() / height
              else -> x.toFloat() / width
            }
          val bucket =
            when {
              normX < 0.33f -> 0
              normX < 0.67f -> 1
              else -> 2
            }
          sums[bucket] += edge
          counts[bucket]++
        }
        x += step
      }
      y += step
    }

    fun normalizedLoad(bucket: Int): Float {
      val c = counts[bucket]
      if (c == 0) return 0f
      return ((sums[bucket] / c) * 5.2f).coerceIn(0f, 1f)
    }

    return ZoneClearance(
      leftObstacleLoad = normalizedLoad(0),
      centerObstacleLoad = normalizedLoad(1),
      rightObstacleLoad = normalizedLoad(2),
    )
  }

  private fun severityRank(severity: HazardSeverity): Int =
    when (severity) {
      HazardSeverity.CRITICAL -> 3
      HazardSeverity.CAUTION -> 2
      HazardSeverity.INFO -> 1
      HazardSeverity.CLEAR -> 0
    }

  companion object {
    private const val ANALYSIS_INTERVAL_MS = 220L
  }
}
