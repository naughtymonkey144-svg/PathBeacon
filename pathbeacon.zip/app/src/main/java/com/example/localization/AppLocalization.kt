package com.example.localization

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.text.TextUtils
import android.view.View
import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.LayoutDirection
import java.util.Locale

data class SupportedLanguage(
  val tag: String,
  val nativeName: String,
  val shortCode: String,
)

val SUPPORTED_LANGUAGES: List<SupportedLanguage> =
  listOf(
    SupportedLanguage(tag = "", nativeName = "System Default", shortCode = "AUTO"),
    SupportedLanguage(tag = "en", nativeName = "English", shortCode = "EN"),
    SupportedLanguage(tag = "es", nativeName = "Español", shortCode = "ES"),
    SupportedLanguage(tag = "fr", nativeName = "Français", shortCode = "FR"),
    SupportedLanguage(tag = "de", nativeName = "Deutsch", shortCode = "DE"),
    SupportedLanguage(tag = "ja", nativeName = "日本語", shortCode = "JA"),
    SupportedLanguage(tag = "hi", nativeName = "हिन्दी", shortCode = "HI"),
    SupportedLanguage(tag = "ar", nativeName = "العربية", shortCode = "AR"),
    SupportedLanguage(tag = "zh-CN", nativeName = "简体中文", shortCode = "ZH"),
  )

fun resolveLocale(languageTag: String): Locale {
  if (languageTag.isBlank()) {
    return Locale.getDefault()
  }
  return Locale.forLanguageTag(languageTag)
}

fun resolveLanguageOption(languageTag: String): SupportedLanguage {
  return SUPPORTED_LANGUAGES.firstOrNull { it.tag == languageTag } ?: SUPPORTED_LANGUAGES.first()
}

fun resolveShortBadge(languageTag: String): String {
  if (languageTag.isBlank()) {
    val sysLang = Locale.getDefault().language.uppercase(Locale.US)
    return sysLang.ifBlank { "AUTO" }
  }
  return resolveLanguageOption(languageTag).shortCode
}

fun Context.createLocalizedContext(languageTag: String): Context {
  val locale = resolveLocale(languageTag)
  val config = Configuration(resources.configuration)
  config.setLocale(locale)
  config.setLayoutDirection(locale)
  return createConfigurationContext(config)
}

fun layoutDirectionForTag(languageTag: String): LayoutDirection {
  val locale = resolveLocale(languageTag)
  return if (TextUtils.getLayoutDirectionFromLocale(locale) == View.LAYOUT_DIRECTION_RTL) {
    LayoutDirection.Rtl
  } else {
    LayoutDirection.Ltr
  }
}

val LocalLocalizedContext = staticCompositionLocalOf<Context> {
  error("LocalLocalizedContext must be provided by PathBeaconApp")
}

@Composable
@ReadOnlyComposable
fun localizedString(@StringRes id: Int): String {
  val ctx = LocalLocalizedContext.current
  return ctx.resources.getString(id)
}

@Composable
@ReadOnlyComposable
fun localizedString(@StringRes id: Int, vararg formatArgs: Any): String {
  val ctx = LocalLocalizedContext.current
  return ctx.resources.getString(id, *formatArgs)
}

@Composable
fun rememberLocalizedContext(languageTag: String): Context {
  val baseContext = LocalContext.current
  return androidx.compose.runtime.remember(baseContext, languageTag) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && languageTag.isBlank()) {
      baseContext
    } else {
      baseContext.createLocalizedContext(languageTag)
    }
  }
}
