package com.example.audio

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.localization.resolveLocale
import com.example.model.HazardSeverity
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class CueSpeaker(context: Context) {

  private val appContext = context.applicationContext
  private var tts: TextToSpeech? = null
  private var isTtsReady = false
  private var currentRate = 1.0f
  private var currentLanguageTag = ""
  private var pendingText: String? = null

  private val _isSpeaking = MutableStateFlow(false)
  val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

  private val _isTtsLanguageAvailable = MutableStateFlow(true)
  val isTtsLanguageAvailable: StateFlow<Boolean> = _isTtsLanguageAvailable.asStateFlow()

  private val vibrator: Vibrator? =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      val manager = appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
      manager?.defaultVibrator
    } else {
      @Suppress("DEPRECATION")
      appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

  init {
    tts =
      TextToSpeech(appContext) { status ->
        if (status == TextToSpeech.SUCCESS) {
          val engine = tts
          applyTtsLocale(engine, currentLanguageTag)
          engine?.setSpeechRate(currentRate)
          engine?.setOnUtteranceProgressListener(
            object : UtteranceProgressListener() {
              override fun onStart(utteranceId: String?) {
                _isSpeaking.value = true
              }

              override fun onDone(utteranceId: String?) {
                _isSpeaking.value = false
              }

              @Deprecated("Deprecated in Java")
              override fun onError(utteranceId: String?) {
                _isSpeaking.value = false
              }

              override fun onError(utteranceId: String?, errorCode: Int) {
                _isSpeaking.value = false
              }
            }
          )
          isTtsReady = true
          pendingText?.let { queued ->
            pendingText = null
            speakCue(queued, interrupt = true)
          }
        }
      }
  }

  fun updateLanguageTag(languageTag: String) {
    currentLanguageTag = languageTag
    if (isTtsReady) {
      applyTtsLocale(tts, languageTag)
    }
  }

  private fun applyTtsLocale(engine: TextToSpeech?, languageTag: String) {
    if (engine == null) return
    val targetLocale = resolveLocale(languageTag)
    val result = engine.setLanguage(targetLocale)
    val available =
      result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
    _isTtsLanguageAvailable.value = available
    if (!available) {
      engine.setLanguage(Locale.US)
    }
  }

  fun updateSpeechRate(rate: Float) {
    currentRate = rate.coerceIn(0.75f, 1.75f)
    if (isTtsReady) {
      tts?.setSpeechRate(currentRate)
    }
  }

  fun speakCue(text: String, interrupt: Boolean = true) {
    if (text.isBlank()) return
    if (!isTtsReady) {
      pendingText = text
      return
    }
    val queueMode = if (interrupt) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
    val utteranceId = UUID.randomUUID().toString()
    tts?.setSpeechRate(currentRate)
    tts?.speak(text, queueMode, null, utteranceId)
  }

  fun stopSpeaking() {
    if (isTtsReady) {
      tts?.stop()
    }
    _isSpeaking.value = false
  }

  fun triggerHaptic(severity: HazardSeverity) {
    val vib = vibrator ?: return
    if (!vib.hasVibrator()) return
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val effect =
        when (severity) {
          HazardSeverity.CRITICAL ->
            VibrationEffect.createWaveform(longArrayOf(0, 120, 60, 160), -1)
          HazardSeverity.CAUTION ->
            VibrationEffect.createOneShot(90L, VibrationEffect.DEFAULT_AMPLITUDE)
          HazardSeverity.INFO ->
            VibrationEffect.createOneShot(45L, 140)
          HazardSeverity.CLEAR ->
            VibrationEffect.createOneShot(30L, 90)
        }
      vib.vibrate(effect)
    } else {
      @Suppress("DEPRECATION")
      val duration =
        when (severity) {
          HazardSeverity.CRITICAL -> 220L
          HazardSeverity.CAUTION -> 90L
          HazardSeverity.INFO -> 45L
          HazardSeverity.CLEAR -> 30L
        }
      @Suppress("DEPRECATION")
      vib.vibrate(duration)
    }
  }

  fun release() {
    tts?.stop()
    tts?.shutdown()
    tts = null
    isTtsReady = false
  }
}
