---
name: Clarity Spectrum
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1b1b'
  surface-container: '#1f1f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#cdc7aa'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#303030'
  outline: '#979177'
  outline-variant: '#4b4731'
  surface-tint: '#dec800'
  primary: '#ffffff'
  on-primary: '#373100'
  primary-container: '#fde400'
  on-primary-container: '#716500'
  inverse-primary: '#6a5f00'
  secondary: '#d3fbff'
  on-secondary: '#00363a'
  secondary-container: '#00eefc'
  on-secondary-container: '#00686f'
  tertiary: '#ffffff'
  on-tertiary: '#003919'
  tertiary-container: '#60ff99'
  on-tertiary-container: '#00743a'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#fde400'
  primary-fixed-dim: '#dec800'
  on-primary-fixed: '#201c00'
  on-primary-fixed-variant: '#504700'
  secondary-fixed: '#7df4ff'
  secondary-fixed-dim: '#00dbe9'
  on-secondary-fixed: '#002022'
  on-secondary-fixed-variant: '#004f54'
  tertiary-fixed: '#60ff99'
  tertiary-fixed-dim: '#00e479'
  on-tertiary-fixed: '#00210c'
  on-tertiary-fixed-variant: '#005228'
  background: '#131313'
  on-background: '#e2e2e2'
  surface-variant: '#353535'
typography:
  headline-xl:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.01em
  headline-xl-mobile:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: 0em
  headline-lg-mobile:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: 0em
  headline-md:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: 0.01em
  headline-md-mobile:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: 0.01em
  body-xl:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 34px
    letterSpacing: 0.015em
  body-lg:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0.02em
  body-md:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.02em
  label-lg:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: 0.05em
  label-md:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 15px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Atkinson Hyperlegible Next
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-mobile: 1.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 2rem
  space-xl: 3rem
---

## Brand & Style

This design system delivers an uncompromising, ultra-accessible environment engineered specifically for users with severe visual impairments, low vision, and visual processing fatigue. Rather than treating accessibility as an afterthought or a hidden setting, the core identity celebrates pure utility, hyper-visibility, and tactile architectural presence.

The aesthetic fuses **High-Contrast Brutalism** with **Modern Assistive Minimalism**:
- **Absolute Contrast Ratios:** Built around extreme optical polarity, exceeding WCAG AAA standards (7:1) and frequently hitting 15:1 to 21:1.
- **Architectural Framing:** Thick, distinct structural bounding boxes establish immediate spatial orientation, removing ambiguity across dynamic content boundaries.
- **Tactile Visual Cues:** Crisp edges, unambiguous focus states, heavy pill indicators, and unmistakable interactive targets eliminate micro-navigation friction.
- **Atmospheric Neutrality:** No decorative gradient washes, drop-shadow fuzz, or translucent glass overlays. Surfaces are solid, intentional, and resolute.

## Colors

The system uses a pure dark-mode architecture to minimize screen glare, ocular strain, and photophobia, while optimizing perceived luminance differences for low-vision acuity.

### Functional Palette Logic:
- **Base Canvas (`#000000`):** Pitch black canvas provides the ultimate non-emitting backdrop, forcing foreground components to radiate with crisp optical edges.
- **Foreground Clarity (`#FFFFFF`):** Unadulterated stark white reserved for primary body text, critical data values, and structural primary borders.
- **Primary Focus / Caution (`#FFE600`):** Safety warning yellow acts as the dominant visual anchor. It is dedicated to active selections, mandatory interactive callouts, primary buttons, and keyboard focus states.
- **Secondary Data / Action (`#00F0FF`):** Vibrant electric cyan offers hyper-visibility against pure black, assigned to secondary interactive controls, navigation links, and informational beacons.
- **Tertiary Affirmation (`#00FF88`):** High-contrast emerald green signals positive confirmation, verified states, toggle active indicators, and successful actions.

### State & Contrast Discipline:
- Background containers never mix subtle grays; contrast is binary or step-tiered through solid black with distinct white, yellow, or cyan borders.
- Destructive actions utilize high-luminance crimson (`#FF3B30`), paired always with text descriptors and thick bounding iconography.

## Typography

Typography is powered entirely by **Atkinson Hyperlegible Next**, designed explicitly to differentiate confusing letterforms (such as capital `I`, lowercase `l`, and digit `1`) for readers with visual challenges.

### Layout & Legibility Rules:
- **Weights:** Light and thin weights are strictly prohibited. The system establishes a baseline minimum weight of `400` (Regular) for secondary copy, `500` (Medium) for general body text, and `700` to `800` (Bold/ExtraBold) for all interactive touchpoints, labels, and headings.
- **Proportional Leading:** Line heights are maintained between 140% and 155% of font size to prevent line-collision during optical zoom or hardware-level magnification.
- **Uncluttered Tracking:** Positive letter spacing across small labels guarantees distinct individual glyph identification even at high zoom settings.
- **Never Rely on Scale Alone:** Headings and structural groupings must be reinforced with visual separation rules or bounding borders, never solely size differences.

## Layout & Spacing

The layout model is a robust, fluid grid designed to withstand browser zoom factors up to 400% without horizontal clipping or overlapping containers.

### Responsive Breakpoints:
- **Mobile (< 768px):** Single-column layout. Gutters compress to `1rem` and margins to `1.25rem`. Complex modular panels collapse vertically into predictable, stacked interaction blocks.
- **Tablet (768px – 1024px):** 6-column fluid structure with `1.5rem` gutters.
- **Desktop (> 1024px):** 12-column rigid hierarchy maximizing clarity through intentional whitespace and dedicated target zones.

### Spatial Discipline:
- Touch and click zones enforce a mandatory minimum target dimension of **56px by 56px** (surpassing typical 44px baselines).
- Every primary component must reserve `space-md` (`1.25rem`) padding internally to guarantee text never crowds against heavy bounding frames.

## Elevation & Depth

This system intentionally rejects ambient drop shadows, blurred elevations, and semi-transparent layering, as these artifacts introduce peripheral fuzziness that low-vision users perceive as optical blur or dirt.

### Mechanical Visual Hierarchy:
- **Crisp Structural Borders:** Depth is communicated strictly via 2px to 4px high-contrast vector borders. Active elements sit within `#FFE600` or `#00F0FF` containers, contrasting against `#000000` base canvases.
- **Layer Offset (Hard Drop):** When layered depth is functionally critical (such as modals or popovers), utilize a pure-black card backed by a solid 4px solid `#FFFFFF` or `#FFE600` border, offset by an unblurred 6px hard shadow (`box-shadow: 6px 6px 0px 0px #000000, 6px 6px 0px 2px #FFFFFF`).
- **Surface Inversion:** Visual hierarchy escalates through foreground inversion rather than z-index lifting. Higher priority modules feature inverse fills (e.g., solid `#FFE600` fill with `#000000` text) while resting modules remain dark with high-contrast outlines.

## Shapes

The design uses **Soft (Level 1)** geometry: 4px base radius for standard cards, buttons, and input fields; 8px (`rounded-lg`) for major modals; and zero arbitrary curves.

### Functional Rationale:
- Excessive rounding distorts the perceived rectangular bounds of hit areas for magnified cursor users.
- Near-rectangular forms (with minimal 4px smoothing) optimize readable surface area, maximize usable content space, and preserve crisp vector edge rendering on low-density or high-magnification displays.
- Pill forms are restricted strictly to status badges, micro-tags, and toggle triggers to distinguish informational markers from operable structural panels.

## Components

### Buttons
- **Primary:** Solid `#FFE600` fill, bold `#000000` typography, 3px solid `#FFE600` border. Minimum height `56px`. Focus state triggers an alternating 4px outer ring with a 2px black separation gap.
- **Secondary:** `#000000` fill, `#00F0FF` text, 3px solid `#00F0FF` border. On hover/focus, inverts to solid `#00F0FF` fill with `#000000` text.
- **Destructive:** Solid `#000000` fill with 3px solid `#FF3B30`, `#FFFFFF` bold text accompanied by an explicit crossmark (`[X]`) glyph.

### Status Pills & Chips
- Fully encapsulated with a 2px outline and heavy bold typography.
- Status values pair colors directly with textual prefixes:
  - Active/Online: `#00FF88` border, `#00FF88` text, prefixed with a filled circle glyph `[●]`.
  - Attention/Warning: `#FFE600` border, `#FFE600` text, prefixed with `[!]`.
  - Inactive/Offline: `#FFFFFF` border, `#FFFFFF` text, prefixed with `X�%X�������ܛH�Y[�	�[�]HZY��Z[�[][K�]�X�X��[�\�[܈
�
K\��\�[����Yё������\�[���ܙ\���H��][��܈[�\��[X�[�\�H\�[��Y��]X���X�[[YXY[���[�^\��]\�X�HX�ݙH[�]��]H�X\��X�K^��\��H���\��]N��ܙ\�^[���[�����[[Z[�][��[�X��Y�\�[���\��[�[�]���\˂�HX�Z�\�^]\����X��]]H�܈[����X�ۙ\�H\��\�]�H�ZY[��H\�X�Y�[�X]H�Y[[�M�Y�X�۝�\�ё������������X�؛�\�	��Y[��۝��HZ[�[][H[Y[��[ۜΈ̜�H̜�X����][�HM�YY\��]��H�X�؛�����Yё������]X\�K��[��X��Y�[��]���[�\�^\�H���YX�[�X�[�X���\��H�Y[Έ���Yё�������[YK��[��[X�Y\�^\�[�[�\��[��Y�����X]�[��H��Y�]]�H�X�H�\�������\��	�ܛ�\[���۝Z[�\�H��Y��X��ܛ�[��ܙ\�Y�HHY�[�]]�H���Yё�����܈�������Z\�[�H��[YK��H�X�[ۜ��][��\��\�H�\\�]Y�H�[]�Y���Yё�����ܚ^�۝[]�Y\���[[ݚ[���[X[��Hۈ�X�H�X��ܛ�[�ۙH�\�X][ۜ˂�����[�[�	�X[��H��[YY[�H����Yё�M���[�\�H�][�[��\��Y��Y�X����ٙ��]��H�X��ܛ�[��X����ݙ\�^H\��]��]L	H�X�]K��\][H�\�\��[���X��ܛ�[��\�X[��\�H��\�\��H��\]H���\�ۈHX�]�H\��